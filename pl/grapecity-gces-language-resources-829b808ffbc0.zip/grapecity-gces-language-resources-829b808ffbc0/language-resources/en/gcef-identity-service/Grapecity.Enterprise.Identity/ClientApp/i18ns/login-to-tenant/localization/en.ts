export const en: LanguageKeyValueMap = {
	Ok: 'OK',
	SelectOrganization: 'Please select organization',
}