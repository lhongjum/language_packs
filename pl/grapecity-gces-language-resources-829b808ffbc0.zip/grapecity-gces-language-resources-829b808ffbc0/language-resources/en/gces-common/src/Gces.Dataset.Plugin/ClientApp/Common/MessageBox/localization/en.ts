export const mbLocaleEN = {
    OK: 'OK',
    MessageBox: 'Message',
};
