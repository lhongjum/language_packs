export const ntfLocaleEN = {
    ntfDismiss: 'Dismiss',
    ntfDismissAll: 'Dismiss All',
    ntfShowDetails: 'Show Details',
    ntfShowAll: 'Show All',
    ntfCancelTask: 'Cancel this task',
};
