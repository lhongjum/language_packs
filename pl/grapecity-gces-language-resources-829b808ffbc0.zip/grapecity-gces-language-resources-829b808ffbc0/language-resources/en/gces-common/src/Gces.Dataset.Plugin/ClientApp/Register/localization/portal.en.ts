
export const portalEN = {
	'createDataset!name': 'Create Dataset',
	'createDataset!description': 'Create Dataset',

	'createDatasource!name': 'Create Data Source',
	'createDatasource!description': 'Create Data Source',

	'dsc!name': 'Data Source',
	'dsc!description': 'Data Source',

	'dataset!name': 'Dataset',
	'dataset!description': 'Dataset',

	'modifyDataSource!name': 'Edit...',
	'modifyDataSource!description': 'Edit this document',
	'reconfigDataSource!name': 'Reconfigure',
	'reconfigDataSource!description': 'Reconfigure this document',

	'modifyDataset!name': 'Edit...',
	'modifyDataset!description': 'Edit this document',

	'refreshDataset!name': 'Refresh cache...',
	'refreshDataset!description': 'Refresh cache',

	'incrementalUpdateDataset!name': 'Incremental update cache...',
	'incrementalUpdateDataset!description': 'Incremental update cache',

	'copyDataset!name': 'Duplicate...',
	'copyDataset!description': 'Duplicate this document',

	'psExecute!name': 'Execute',
	'psExecuteAndCreateDataset!name': 'Execute / Create Dataset',
	'appendData!name': 'Append Data',
	'appendData!description': 'Append Data for the selected DataSource',
};
