export const datasetEN: LanguageKeyValueMap = {
	UseConfigString: 'Use Configuration String(Advanced)',
	err_10026: 'Get database list failed. The server is not found or is not accessible. Please verify your settings and make sure the server allows remote connections. If connection still failed, please input the database/service name manually.',
};
