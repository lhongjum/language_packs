export const portalEN: LanguageKeyValueMap = {
  'dbd!name': 'Dashboard',
};
