export default {
  "friendlyName": "JSON",
  "tooltipName": "JSON",
  "settings": {
    "Formatted": {
      "label": "Formatted",
      "category": "Misc"
    },
    "QuotePropertyNames": {
      "label": "QuotePropertyNames",
      "category": "Misc"
    },
    "AddTimestamp": {
      "label": "Add Timestamp",
      "category": "Filename"
    }
  }
}
