export default {
  "friendlyName": "TXT",
  "tooltipName": "TXT Document",
  "settings": {
    "FontWeight": {
      "label": "FontWeight",
      "category": "Misc"
    },
    "FontHeight": {
      "label": "FontHeight",
      "category": "Misc"
    },
    "AddTimestamp": {
      "label": "Add Timestamp",
      "category": "Filename"
    }
  }
}
