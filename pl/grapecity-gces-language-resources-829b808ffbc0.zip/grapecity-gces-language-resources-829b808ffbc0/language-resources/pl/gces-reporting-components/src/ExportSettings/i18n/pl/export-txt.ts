export default {
  "friendlyName": "TXT",
  "tooltipName": "TXT Document",
  "settings": {
    "FontWeight": {
      "label": "GrubośćCzcionki",
      "category": "Różne"
    },
    "FontHeight": {
      "label": "RozmiarCzcionki",
      "category": "Różne"
    },
    "AddTimestamp": {
      "label": "Add Timestamp to filename",
      "category": "Filename"
    }
  }
}
