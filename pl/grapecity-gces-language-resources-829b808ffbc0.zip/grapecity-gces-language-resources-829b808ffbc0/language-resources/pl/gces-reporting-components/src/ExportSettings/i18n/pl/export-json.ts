export default {
  "friendlyName": "JSON",
  "tooltipName": "JSON",
  "settings": {
    "Formatted": {
      "label": "Sformatowane",
      "category": "Różne"
    },
    "QuotePropertyNames": {
      "label": "CytujNazwyWłaściwości",
      "category": "Różne"
    },
    "AddTimestamp": {
      "label": "Add Timestamp to filename",
      "category": "Filename"
    }
  }
}
