﻿export const pl: LanguageKeyValueMap = {
	Ok: 'OK',
	SelectOrganization: 'Please select organization',
}