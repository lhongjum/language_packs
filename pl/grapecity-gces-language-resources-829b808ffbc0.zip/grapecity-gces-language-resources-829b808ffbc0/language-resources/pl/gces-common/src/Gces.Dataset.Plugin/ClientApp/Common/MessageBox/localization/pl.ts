export const mbLocalePL = {
    OK: 'OK', // OK
    MessageBox: 'Wiadomość', // Message
};
