export const ntfLocalePL = {
    ntfDismiss: 'Odrzuć', // Dismiss
    ntfDismissAll: 'Odrzuć wszystkie', // Dismiss All
    ntfShowDetails: 'Pokaż szczegóły', // Show Details
    ntfShowAll: 'Pokaż wszystkie', // Show All
    ntfCancelTask: 'Przerwij to zadanie', // Cancel this task
};
