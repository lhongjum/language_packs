export const portalZhTW: LanguageKeyValueMap = {
  'shortcut-dashboards!description': '',
  'shortcut-dashboards!props!text': '儀表板',
  'shortcut-dashboards!title': '儀表板磁貼',

  'dashboardsConfiguration!title': '儀表板設置',
  'dashboardsConfiguration!description': '儀表板功能相關的設置選項',
  'dashboardsConfiguration!containerFilterScope': '容器過濾範圍',
  'dashboardsConfiguration!containerFilterScope!Container': '當前容器',
  'dashboardsConfiguration!containerFilterScope!Global': '整個頁面',
  'dashboardsConfiguration!maxAggregatedDataPoints': '聚合數據點上限值',
  'dashboardsConfiguration!enableDeveloperMode': '啟用開發者模式',
};
