export const parameterPanelZHTW: LanguageKeyValueMap = {
  // Parameters Panel
  paramPanelTextNoParameters: '該儀表板沒有查詢條件',
  hiddenParamsError: '該儀表板包含無效的隱藏參數',
  // Saga
  sagaValidationTextValueExpected: '必填',
  sagaValidationTextNoEmptyStrings: '不能為空',
  sagaValidationTextValidBoolean: '格式錯誤，需要布爾值',
  sagaValidationTextValidInteger: '格式錯誤，需要整數',
  sagaValidationTextValidFloat: '格式錯誤，需要浮點數',
  sagaValidationTextValidDateTime: '格式錯誤，需要日期時間',
  sagaValidationTextUnknownError: '未知錯誤',
  sagaValidationTextNoNull: '必填項',
  sagaValidationTextPickFromList: '請從列表中選擇數據',
  sagaValidationTextMaxInteger: '數字值不能超過32位整數的最大值',
  // All Parameters
  paramsTextInvalidValue: '無效數據',
  // MultiValueParameter
  mvpTextAllValues: '全選',
  mvpTextSelectValue: '(請選擇)',
  mvpTextSelectAll: '(全選)',
  mvpTextResetAll: '(重置)',
  // BooleanParameter
  bpTextTrue: '是',
  bpTextFalse: '否',
  // DropdownParameter
  ddpTextSelectValue: '(請選擇)',
  ddpTextNull: '(空值)',
};
