export const portalZhTW: LanguageKeyValueMap = {
  'dbd!name': '儀表板',
};
