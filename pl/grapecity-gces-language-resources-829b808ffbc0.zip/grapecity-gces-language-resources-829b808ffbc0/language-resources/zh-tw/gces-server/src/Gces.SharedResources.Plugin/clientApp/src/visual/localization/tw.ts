export const portalResourceTW: LanguageKeyValueMap = {
	'set-configuration!name': '設定引數',
	'set-configuration!description': '設定引數',
	'rename-visual!name': '重命名文檔',
	'rename-visual!description': '重命名文檔',
};

export const shareResourceTW: LanguageKeyValueMap = {
	'setConfiguration': '設定引數',
	'noConfiguration': '沒有可用引數',
	'rename': '重命名',
	'isTrusted': '信任該插件',
	'switchTrue': '是',
	'switchFalse': '否',
};