export const portalResourceTW: LanguageKeyValueMap = {
	'shortcut-categories!description': '',
	'shortcut-categories!props!text': '門戶目錄',
	'shortcut-categories!title': '門戶目錄磁貼',
	'geojson-storge-management!title': '地圖信息',
	'geojson-storge-management!description': 'GeoJson 管理',
	'shortcut-themes!description': '',
	'shortcut-themes!props!text': '主題',
	'shortcut-themes!title': '主題磁貼',
	'shortcut-image!description': ' ',
	'shortcut-image!props!text': '圖片',
	'shortcut-image!title': '圖片磁貼',
	'rename-geo!name': '重命名文檔',
	'rename-geo!description': '重命名文檔'
};

export const shareResourceTW: LanguageKeyValueMap = {
	// Header
	headerItemTextUploadNew: '上傳文檔',
	headerItemHeaderAddNew: '新建文檔',
	headerItemTextAdminPortal: '系統管理',
	headerItemTextLogout: '退出登錄',
	repeatName: '文檔({{newName}}) 已經存在',
	renameDocNotFound: '文檔找不到(可能已被移除，請刷新當前頁)',
	noRenameDocPermission: '沒有權限重命名當前文檔',

	// Upload Dialog
	udTextFiles: '{{count}} 個文件',
	udTextFiles_plural: '{{count}} 個文件',

	udTitleUpload: '上傳文檔',
	udTitleUploading: '正在上傳...',

	udTextStatusNoFiles: '沒有選擇任何文件',
	udTextStatusInitializing: '初始化...',
	udTextStatusInProgress: '已經上傳 {{total}} 個中的 {{count}} 個文檔',

	udTextStatusReadyToCommitPartial: '準備提交 {{total}} 個中的 {{countText}}',
	udTextStatusReadyToCommit: '驗證完畢，可以提交',

	udHeaderInvalid: '無效的文檔',
	udHeaderUnresolved: '未識別的文檔',
	udHeaderAlreadyExists: '已存在的文檔(請選擇上傳方式)',
	udHeaderReadyToCommit: '新上傳的文檔',
	udHeaderUploading: '正在上傳',

	udBtnTextCommit: '提交',
	udBtnTextCommitValidOnly: '僅上傳有效文檔',
	udBtnTextCancel: '取消',

	udDNDTextDropFiles: '拖拽文檔到這裡',
	udDNDTextClickHere: '或者點擊這裡去選擇文檔',

	// Upload File Item
	ufiTextUploading: '正在上傳...',
	ufiBtnTitleKeepBoth: '作為新文檔上傳',
	ufiBtnTitleOverwrite: '覆蓋現有同名的文檔',

	// Upload Saga
	usErrorTextSessionError: '上傳會話錯誤',
	usErrorTextValidationError: '驗證',
	usErrorTextValidationErrorDetails: '抱歉! 我們不能得到有效的狀態。 ',
	usErrorTextUploadCommitError: '上傳錯誤',
	usErrorTextUploadCommitErrorDetails: '抱歉！我們不能上傳。 ',
	usErrorTextCancelationError: '抱歉！我們不能取消這個正在上傳的文件。 ',

	// Upload Other
	uoTextUnknownFileType: '未知的文檔類型',
	uoTextUnsupportedFileType: '不支持的文檔類型',

	rename: '重命名',
	untitled: '未命名',
	save: '保存',
	cancel: '取消',
	name: '名稱',
	description: '描述',
	OK: '確定',
	Close: '關閉',
	messageBox: '消息提示',
	hierarchyEditorTitle: 'Hierarchy 編輯器',
	geoJsonSearchPlaceHolder: '查找 geojson',
	noGeoJsonTip: '沒有Geojson數據，請先上傳數據',
	noGeoJsonMatchTip: '沒有匹配的Geojson',
	dropGeojsonHere: '拖拽geojson到當前區域',
	joinTitle: '連接',
	equals: '等於',
	joinTo: '連接到',
	joinInfo: '選擇左表“{{leftTableTitle}}”的屬性名及值連接到右表“{{rightTableTitle}}”',
	error_300000: '未知錯誤!',
	error_300001: '文檔已經存在!',
	error_300002: '該文檔正被其他文檔引用!',
	error_300003: '無法訪問該文檔!',
	error_300004: '文檔格式不合法!',
	error_300005: '文檔已被移除!',
	error_300006: '文檔不存在!',

	UnknowError: '未知錯誤!',
};