export const portalTW: LanguageKeyValueMap = {
	// Common
	more: '更多...',

	// Loader
	layoutGettingReady: '正在為您準備文檔列表，請稍等...',
	layoutPortCanNotStart: '服務未能啟動，請與管理員聯繫...',

	// System Tags
	sysTagNoCategory: '未分類',
	sysTagResources: '資源庫',
	sysTagFavorites: '收藏夾',
	sysTagImages: '圖片',
	sysTagThemes: '主題',
	sysTagFloorPlans: '自定義地圖',

	// Plugin Tags
	pluginDataset: '數據集',
	pluginDataSource: '數據源',
	pluginSemanticModel: '語義模型',
	pluginTemplates: '報表模板',
	pluginMasters: '母版報表',

	// Notifications
	ntfDismiss: '忽略',
	ntfDismissAll: '忽略所有',
	ntfShowDetails: '顯示詳情',
	ntfShowAll: '顯示所有',
	ntfCancelTask: '取消這個任務',

	// Documents View
	docViewHeaderCategories: '文檔分類',
	docViewHeaderDocuments: '文檔列表',
	docViewDocsCount: '{{count}} 個文檔',
	docViewDocsCount_plural: '{{count}} 個文檔',

	// Expanded Documents View
	docViewExpHeaderCategories: '$t(docViewHeaderCategories)',
	docViewExpHeaderDocuments: '$t(docViewHeaderDocuments)',
	docViewExpHeaderDetails: '詳細信息',

	// Permissions
	psPermissions: '訪問權限',
	psShare: '分享管理',
	psNoSharing: '該文檔沒有被分享',
	'psExecute!name': 'Execute',
	'psRead!name': '只讀',
	'psReadWrite!name': '讀寫',
	psCancel: '取消',
	psSave: '保存',

	// Command Bar
	cbCritName: '名稱',
	cbCritType: '類型',
	cbCritDateUpdated: '更新時間',
	cbCritDateCreated: '創建時間',
	cbSort: '排序',
	cbFilterByDocumentType: '按文檔類型過濾',
	cbSearch: '搜索',

	cbViewModeList: '列表',
	cbViewModeTree: '樹形',
	cbTitleSwitchViewMode: '切換為{{mode}}菜單',
	cbPersonalTagManagement: '管理個人分類',

	cbLayoutModeDefault: '瀏覽',
	cbLayoutModeExpanded: '管理',
	cbTitleSwitchLayoutMode: '切換為文檔{{mode}}視圖',

	// Header
	headerItemTextUploadNew: '上傳文檔',
	headerItemHeaderAddNew: '新建文檔',
	headerItemTextAdminPortal: '系統管理',
	headerItemTextLogout: '退出登錄',
	headerCategoriesAndDocuments: '文檔分類',

	// Main Menu
	menuExpand: '展開菜單 ',
	menuCollapse: '折疊菜單',

	// Nav
	navFavorites: '收藏夾',
	navCategories: '分類',

	// nav org
	globalOrgName: '全局組織',
	switchOrganization: '切換組織',
	editProfileSetting: '編輯個人配置',

	// Upload Dialog
	udTextFiles: '{{count}} 個文件',
	udTextFiles_plural: '{{count}} 個文件',

	udTitleUpload: '上傳文檔',
	udTitleUploading: '正在上傳...',

	udTextStatusNoFiles: '沒有選擇任何文件',
	udTextStatusInitializing: '初始化...',
	udTextStatusInProgress: '已經上傳 {{total}} 個中的 {{count}} 個文檔',

	udTextStatusReadyToCommitPartial: '準備提交 {{total}} 個中的 {{countText}}',
	udTextStatusReadyToCommit: '驗證完畢，可以提交',

	udHeaderInvalid: '無效的文檔',
	udHeaderUnresolved: '不能上傳的文檔',
	udHeaderReferenceUnresolved: '缺少引用的文檔',
	udHeaderAlreadyExists: '已存在的文檔(請選擇上傳方式)',
	udHeaderReadyToCommit: '新上傳的文檔',
	udHeaderUploading: '正在上傳',

	udBtnTextCommit: '提交',
	udBtnTextCancel: '取消',
	udBtnTextClose: '關閉',

	udDNDTextDropFiles: '拖拽文檔到這裡',
	udDNDTextClickHere: '或者點擊這裡去選擇文檔',

	// Upload File Item
	ufiTextUploading: '正在上傳...',
	ufiBtnTitleKeepBoth: '作為新文檔上傳',
	ufiBtnTitleOverwrite: '覆蓋現有同名的文檔',

	// Upload Saga
	usErrorTextSessionError: '上傳會話錯誤',
	usErrorTextValidationError: '驗證',
	usErrorTextValidationErrorDetails: '抱歉，獲取驗證結果有效狀態失敗。 ',
	usErrorTextUploadCommitError: '上傳錯誤',
	usErrorTextUploadCommitErrorDetails: '抱歉，上傳文檔失敗。 ',
	usErrorTextCancellationError: '抱歉，無法取消正在上傳的文檔。 ',

	// Information panel
	infoPanelProperties: '文檔屬性',
	infoPanelUpdated: '更新時間',
	infoPanelUpdatedBy: '更新者',
	infoPanelCreated: '創建時間',
	infoPanelCreatedBy: '創建者',
	infoPanelPermissions: '訪問權限',
	infoPanelCategories: '文檔分類',
	infoPanelDescription: '文檔描述',
	infoPanelDescriptionPlaceholder: '請輸入文檔描述',
	infoPanelMobileVisible: '移動端顯示',
	infoPanelMobileVisibleShow: '顯示',
	infoPanelMobileVisibleHide: '隱藏',
	infoPanelHideInDocumentPortal: '在文檔門戶中隱藏',
	infoPanelHideInDocumentPortalShowStateLabel: '否',
	infoPanelHideInDocumentPortalHideStateLabel: '是',

	// Document info
	docInfoRevisions: '修訂歷史',
	docInfoInfo: '基本信息',
	docInfoSelectDocumentText: '選擇一個文檔查看詳細信息',
	docInfoNoComment: '沒有描述',
	commentWithVersion: '版本 {{no}}: {{comment}}',

	// Search drawer
	searchDrawerSearch: '搜索',
	searchDrawerNoResult: '沒有查到任何結果',
	searchDrawerTip: '請輸入文檔名稱',
	searchDrawerResult: '搜索結果',

	// Document list
	docListNoDocuments: '該分類中沒有文檔',
	docListSortName: '名稱',
	docListSortType: '類型',
	docListSortModified: '修改時間',
	docListSortCreated: '創建時間',

	// Document item
	docItemSetAsHome: '設為主頁',
	docItemSetAsHomeDescription: '這個文檔將默認被打開',
	docItemRename: '重命名',
	docItemRenameDescription: '重命名文檔',
	docItemSetCategory: '管理分類',
	docItemSetCategoryDescription: '編輯文檔的分類',
	docItemSetDelete: '刪除文檔',
	docItemSetDeleteDescription: '刪除這個文檔',
	docItemEdit: '編輯文檔',
	docItemEditTitle: '編輯這個文檔',
	docItemAddToFavorites: '收藏',
	docItemRemoveFromFavorites: '取消收藏',
	docItemDownload: '下載',
	docItemDownloadDescription: '下載該文檔',

	// Tag editor
	tagsEditorCategories: '管理分類',
	tagsEditorCurrent: '已選分類',
	tagsEditorNoCategoriesText: '未設置任何分類',
	tagsEditorAvailableCategories: '可選分類',
	tagsEditorNoAvailableCategories: '沒有可選的分類',

	// Document delete dialog
	deleteDocumentDialogTitle: '刪除文檔',
	deleteDocumentConfirmMsg: '永久刪除文檔“{{name}}”？ ',
	ok: '確定',
	cancel: '取消',
	close: '關閉',
	back: '返回',

	// Workspace
	workspaceInfo: '詳情',
	workspaceRefresh: '刷新',
	workspaceFullscreen: '全屏',
	workspaceNewWindow: '在新窗口中瀏覽{{type}}',
	workspaceNoDocumentTip: '歡迎您使用本產品，請進行以下操作',
	workspaceNoHomeTip: '您還未設置個人主頁，請從左側菜單開始使用文檔',
	workspaceOpenSomeDocuments: '查看文檔',
	workspacePickDocumentToOpen: '從左邊列表中選擇文檔進行查看',
	workspaceSetUpHome: '設置主頁',
	workspaceChooseFromMenu: '從左邊列表中選擇文檔，點擊',
	workspaceSetAsHome: '',
	workspaceCloseAll: '關閉全部標籤頁',
	workspaceCloseAllButActive: '關閉其他標籤頁',
	workspaceCloseActive: '關閉當前標籤頁',
	workspacePreviewIsUnavailable: '此文檔類型不支持預覽 :(',

	// Document Types
	'rdl!name': '報表',
	'rdl!description': '報表',
	'rdlx-template!name': '報表模板',
	'rdlx-template!description': '報表模板',
	'rdlx-master!name': '母版報表',
	'rdlx-master!description': '母版報表',
	'theme!name': '主題',
	'theme!description': '主題',
	'dbd!name': '儀表板',
	'dbd!description': '儀表板',
	'dsc!name': '數據源',
	'dsc!description': '數據源',
	'dataset!name': '數據集',
	'dataset!description': '數據集',

	'image/bmp!name': 'BMP 圖片',
	'image/bmp!description': '位圖圖片',
	'image/jpeg!name': 'JPEG 圖片',
	'image/jpeg!description': 'JPEG 圖片',
	'image/gif!name': 'GIF 圖片',
	'image/gif!description': 'GIF 圖片',
	'image/png!name': 'PNG 圖片',
	'image/png!description': 'PNG 圖片',

	// Verbs
	'imagePreview!name': '圖片預覽',
	'imagePreview!description': '圖片預覽',

	// Document Verbs
	'imagePreviewRevision!name': '圖片預覽',
	'imagePreviewRevision!description': '圖片預覽',
	'copyReport!name': '複製',
	'copyReport!description': '複製這個文檔',
	'copyDashboard!name': '複製',
	'copyDashboard!description': '複製這個文檔',
	'copySemanticModel!name': '複製',
	'copySemanticModel!description': '複製這個文檔',

	// Document Info
	'schedule_tasks!name': '運行計劃',
	'schedule_tasks!description': '文檔的運行計劃管理',
	'schedule_history!name': '運行歷史',
	'schedule_history!description': '文檔運行的歷史記錄',

	// Portal sagas
	connectionError: '連接錯誤',
	initializeError: '初始化錯誤',
	noPluginsFound: '未發現任何插件',
	incorrectCategories: '錯誤的標籤',
	getHomeDocumentError: '獲取主文檔失敗',
	updateDocListError: '更新文檔列表失敗',
	somethingWentWrong: '發生了未知錯誤',
	categoryCannotAvailable: '文檔分類"{{name}}"已經不存在了。它也許被移動，重命名或者刪除了。 ',
	documentNotDeleted: '文檔刪除失敗',
	documentUsedByAnother: '文檔\"{{docName}}\"不能被刪除，該文檔被下列文檔引用：\n{{refDocNames}}',
	changePermissionError: '更新文檔權限失敗',
	assignCategoryError: '指定文檔分類失敗',
	createCategoryError: '創建文檔分類失敗',
	updateCategoryError: '更新文檔分類失敗',
	wrongDataFormat: '錯誤的數據格式',
	renameDocumentError: '重命名文檔失敗',
	duplicateDocumentError: '複製文檔失敗',
	duplicateDocumentSuccess: '複製文檔成功',
	copyDocumentSuffix: '-副本',

};
