export const errorTW: LanguageKeyValueMap = {
	err_default: '出現了一個錯誤，抱歉！',
	err_invalid_license: '無效的產品授權',
	err_invalid_license_desc: '產品授權已經過期.請聯繫你的管理員。',
	err_invalid_license_verion_not_match_desc: '授權和產品版本不匹配,請嘗試刷新授權。',
	adminPortal: '系統管理',

	// Reports
	err_reports_10001: '報表文檔數量已經達到限制，無法創建新報表。',

	// Dashboards
	err_dashboards_10001: '儀表板文檔數量已經達到限制，無法創建新儀表板。',

	// common
	err_common_10001: '此文檔已經被刪除，請刷新文檔列表。',
	err_common_10002: '您沒有這個文檔的訪問權限，請刷新文檔列表。',
	err_common_10003: '您沒有權限訪問此頁面，或者您在訪問一個無效鏈接。',
};