import { Encoding } from "./common/Encoding";

export default {
  "friendlyName": "CSV",
  "tooltipName": "CSV Document",
  "settings": {
    "Encoding": {
      "label": "編碼方式",
      "category": "雜項",
      "enum": Encoding
    },
    "NoHeader": {
      "label": "無標題",
      "category": "雜項"
    },
    "ColumnsDelimiter": {
      "label": "列分隔符",
      "category": "雜項"
    },
    "RowsDelimiter": {
      "label": "行分隔符",
      "category": "雜項"
    },
    "QuotationSymbol": {
      "label": "引文符號",
      "category": "雜項"
    },
    "Extension": {
      "label": "擴展名",
      "category": "雜項",
      "enum": {
        "csv": ".csv",
        "txt": ".txt"
      }
    },
    "AddTimestamp": {
      "label": "文件名稱追加時間戳",
      "category": "文件名稱"
    }
  }
}
