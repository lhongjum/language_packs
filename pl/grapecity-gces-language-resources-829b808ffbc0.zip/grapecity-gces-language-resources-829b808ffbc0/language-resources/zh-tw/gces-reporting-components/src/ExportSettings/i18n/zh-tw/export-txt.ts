export default {
  "friendlyName": "TXT",
  "tooltipName": "TXT Document",
  "settings": {
    "FontWeight": {
      "label": "字體粗細",
      "category": "雜項"
    },
    "FontHeight": {
      "label": "字體高度",
      "category": "雜項"
    },
    "AddTimestamp": {
      "label": "文件名稱追加時間戳",
      "category": "文件名稱"
    }
  }
}
