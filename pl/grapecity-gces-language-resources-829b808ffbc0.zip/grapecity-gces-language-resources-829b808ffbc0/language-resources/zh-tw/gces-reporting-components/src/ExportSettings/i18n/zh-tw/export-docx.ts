import { PaperSize } from './common/PaperSize';

export default {
  "friendlyName": "Word",
  "tooltipName": "Word Document(.docx)",
  "settings": {
    "Title": {
      "label": "標題",
      "category": "雜項"
    },
    "Author": {
      "label": "作者",
      "category": "雜項"
    },
    "DpiX": {
      "label": "橫向分辨率",
      "category": "雜項"
    },
    "DpiY": {
      "label": "縱向分辨率",
      "category": "雜項"
    },
    "DocumentCompatibilityVersion": {
      "label": "文檔兼容性版本",
      "category": "雜項",
      "enum": {
        "Word2007": "Word2007",
        "Word2010": "Word2010",
        "Word2013": "Word2013"
      }
    },
    "TOCAutoUpdate": {
      "label": "TOC自動更新",
      "category": "雜項"
    },
    "CompanyName": {
      "label": "公司名",
      "category": "雜項"
    },
    "WritePassword": {
      "label": "寫密碼",
      "category": "安全設定"
    },
    "Password": {
      "label": "密碼",
      "category": "安全設定"
    },
    "ReadOnlyRecommended": {
      "label": "只讀推薦",
      "category": "安全設定"
    },
    "Orientation": {
      "label": "頁面方向",
      "category": "頁面設置",
      "enum": {
        "Default": "默認",
        "Portrait": "縱向",
        "Landscape": "橫向"
      }
    },
    "PaperSize": {
      "label": "紙張尺寸",
      "category": "頁面設置",
      "enum": PaperSize
    },
    "AddTimestamp": {
      "label": "文件名稱追加時間戳",
      "category": "文件名稱"
    }
  }
}
