import { WatermarkColor } from "./common/WatermarkColor";
import { WatermarkFontFamily } from "./common/WatermarkFontFamily";

export default {
  "friendlyName": "圖片",
  "tooltipName": "PNG Image",
  "settings": {
    "ImageType": {
      "label": "圖像類型",
      "category": "雜項",
      "enum": {
        "Png": "PNG",
        "Jpeg": "JPEG",
        "Gif": "GIF",
        "Bmp": "BMP",
        "Tiff": "TIFF"
      }
    },
    "Pagination": {
      "label": "分頁",
      "category": "雜項"
    },
    "DpiX": {
      "label": "橫向分辨率",
      "category": "雜項"
    },
    "DpiY": {
      "label": "縱向分辨率",
      "category": "雜項"
    },
    "Quality": {
      "label": "質量",
      "category": "雜項"
    },
    "Dither": {
      "label": "抖動",
      "category": "雜項"
    },
    "PrintLayoutMode": {
      "label": "打印版面模式",
      "category": "雜項",
      "enum": {
        "OneLogicalPageOnSinglePhysicalPage": "每版打印 1 页",
        "TwoLogicalPagesOnSinglePhysicalPage": "每版打印 2 页",
        "FourLogicalPagesOnSinglePhysicalPage": "每版打印 4 页",
        "EightLogicalPagesOnSinglePhysicalPage": "每版打印 8 頁",
        "BookletMode": "小冊子模式"
      }
    },
    "SizeToFit": {
      "label": "尺寸適合",
      "category": "雜項"
    },
    "StartPage": {
      "label": "首頁",
      "category": "雜項"
    },
    "EndPage": {
      "label": "結束頁",
      "category": "雜項"
    },
    "WatermarkAngle": {
      "label": "水印角度",
      "category": "雜項"
    },
    "WatermarkColor": {
      "label": "水印顏色",
      "category": "雜項",
      "enum": WatermarkColor
    },
    "WatermarkTitle": {
      "label": "水印標題",
      "category": "雜項"
    },
    "WatermarkFontFamily": {
      "label": "水印字體",
      "category": "雜項",
      "enum": WatermarkFontFamily
    },
    "WatermarkFontSize": {
      "label": "水印字體大小",
      "category": "雜項"
    },
    "WatermarkFontBold": {
      "label": "水印字體粗體",
      "category": "雜項"
    },
    "WatermarkFontItalic": {
      "label": "水印字體斜體",
      "category": "雜項"
    },
    "WatermarkFontStrikeout": {
      "label": "水印字體刪除線",
      "category": "雜項"
    },
    "WatermarkFontUnderline": {
      "label": "水印字體下劃線",
      "category": "雜項"
    },
    "AddTimestamp": {
      "label": "文件名稱追加時間戳",
      "category": "文件名稱"
    }
  }
}
