import { WatermarkColor } from "./common/WatermarkColor";
import { WatermarkFontFamily } from "./common/WatermarkFontFamily";

export default {
  "friendlyName": "PDF",
  "tooltipName": "PDF Document",
  "settings": {
    "Version": {
      "label": "版本",
      "category": "雜項",
      "enum": {
        "Pdf12": "PDF-1.2",
        "Pdf13": "PDF-1.3",
        "Pdf14": "PDF-1.4",
        "Pdf15": "PDF-1.5",
        "Pdf16": "PDF-1.6",
        "Pdf17": "PDF-1.7",
        "PdfA1a": "PDF/A-1a",
        "PdfA1b": "PDF/A-1b",
        "PdfA2a": "PDF/A-2a",
        "PdfA2b": "PDF/A-2b",
        "PdfA2u": "PDF/A-2u",
        "PdfA3a": "PDF/A-3a",
        "PdfA3b": "PDF/A-3b",
        "PdfA3u": "PDF/A-3u",
        "PdfUA1": "PDF/UA-1"
      }
    },
    "EmbedFonts": {
      "label": "嵌入字體",
      "category": "雜項",
      "enum": {
        "Partial": "部分",
        "All": "所有",
        "None": "沒有"
      }
    },
    "NeverEmbedFonts": {
      "label": "永不嵌入字體",
      "category": "雜項"
    },
    "PrintOnOpen": {
      "label": "打開打印",
      "category": "雜項"
    },
    "Title": {
      "label": "標題",
      "category": "雜項"
    },
    "Author": {
      "label": "作者",
      "category": "雜項"
    },
    "Subject": {
      "label": "主題",
      "category": "雜項"
    },
    "Keywords": {
      "label": "關鍵詞",
      "category": "雜項"
    },
    "Application": {
      "label": "應用",
      "category": "雜項"
    },
    "Permissions": {
      "label": "权限",
      "category": "信息",
      "enum": {
        "None": "無",
        "AllowPrint": "允許打印",
        "AllowModifyContents": "允許修改",
        "AllowCopy": "允許複製",
        "AllowModifyAnnotations": "允許修改註釋",
        "AllowFillIn": "允許填寫表單",
        "AllowAccessibleReaders": "複製內容用於輔助工具",
        "AllowAssembly": "允許文檔組合",
        "Default": "默認"
      }
    },
    "Use128Bit": {
      "label": "使用128位",
      "category": "雜項"
    },
    "HideToolbar": {
      "label": "隱藏工具欄",
      "category": "雜項"
    },
    "HideMenubar": {
      "label": "隱藏菜單欄",
      "category": "雜項"
    },
    "HideWindowUI": {
      "label": "隱藏窗口界面",
      "category": "雜項"
    },
    "FitWindow": {
      "label": "適合窗口",
      "category": "雜項"
    },
    "CenterWindow": {
      "label": "窗口中心",
      "category": "雜項"
    },
    "DisplayTitle": {
      "label": "顯示標題",
      "category": "雜項"
    },
    "DisplayMode": {
      "label": "顯示模式",
      "category": "雜項",
      "enum": {
        "None": "沒有",
        "Outlines": "綱要",
        "Thumbs": "縮略圖",
        "FullScreen": "全屏"
      }
    },
    "DuplexMode": {
      "label": "雙工模式",
      "category": "雜項",
      "enum": {
        "Simplex": "單面",
        "DuplexFlipLongEdge": "雙面翻轉長邊",
        "DuplexFlipShortEdge": "雙面翻轉短邊"
      }
    },
    "NumberOfCopies": {
      "label": "複印數量",
      "category": "雜項"
    },
    "ImageInterpolation": {
      "label": "圖像插值",
      "category": "雜項",
      "enum": {
        "Default": "默认",
        "None": "無"
      }
    },
    "PaperSourceByPageSize": {
      "label": "紙張來源（按頁面大小）",
      "category": "雜項"
    },
    "PrintPageRange": {
      "label": "打印頁面範圍",
      "category": "雜項"
    },
    "IsPaginated": {
      "label": "分頁",
      "category": "雜項"
    },
    "PrintLayoutMode": {
      "label": "打印版面模式",
      "category": "雜項",
      "enum": {
        "OneLogicalPageOnSinglePhysicalPage": "每版打印 1 页",
        "TwoLogicalPagesOnSinglePhysicalPage": "每版打印 2 页",
        "FourLogicalPagesOnSinglePhysicalPage": "每版打印 4 页",
        "EightLogicalPagesOnSinglePhysicalPage": "每版打印 8 頁",
        "BookletMode": "小冊子模式"
      }
    },
    "SizeToFit": {
      "label": "尺寸適合",
      "category": "雜項"
    },
    "StartPage": {
      "label": "首頁",
      "category": "雜項"
    },
    "EndPage": {
      "label": "結束頁",
      "category": "雜項"
    },
    "WatermarkAngle": {
      "label": "水印角度",
      "category": "雜項"
    },
    "WatermarkColor": {
      "label": "水印顏色",
      "category": "雜項",
      "enum": WatermarkColor
    },
    "WatermarkTitle": {
      "label": "水印標題",
      "category": "雜項"
    },
    "WatermarkFontFamily": {
      "label": "水印字體",
      "category": "雜項",
      "enum": WatermarkFontFamily
    },
    "WatermarkFontSize": {
      "label": "水印字體大小",
      "category": "雜項"
    },
    "WatermarkFontBold": {
      "label": "水印字體粗體",
      "category": "雜項"
    },
    "WatermarkFontItalic": {
      "label": "水印字體斜體",
      "category": "雜項"
    },
    "WatermarkFontStrikeout": {
      "label": "水印字體刪除線",
      "category": "雜項"
    },
    "WatermarkFontUnderline": {
      "label": "水印字體下劃線",
      "category": "雜項"
    },
    "Encrypt": {
      "label": "加密",
      "category": "安全設定"
    },
    "OwnerPassword": {
      "label": "所有者密碼",
      "category": "安全設定"
    },
    "UserPassword": {
      "label": "用戶密碼",
      "category": "安全設定"
    },
    "AddTimestamp": {
      "label": "文件名稱追加時間戳",
      "category": "文件名稱"
    }
  }
}
