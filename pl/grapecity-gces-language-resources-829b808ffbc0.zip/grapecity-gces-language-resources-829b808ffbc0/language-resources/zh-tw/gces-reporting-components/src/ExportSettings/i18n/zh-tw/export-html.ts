export default {
  "friendlyName": "HTML",
  "tooltipName": "HTML Document",
  "settings": {
    "EmbedImages": {
      "label": "嵌入圖片",
      "category": "導出"
    },
    "Fragment": {
      "label": "分段",
      "category": "導出"
    },
    "StyleStream": {
      "label": "風格流",
      "category": "導出"
    },
    "OutputTOC": {
      "label": "輸出目錄",
      "category": "導出"
    },
    "RenderMode": {
      "label": "模式",
      "category": "渲染中",
      "enum": {
        "Galley": "不分頁",
        "Paginated": "分頁"
      }
    },
    "RenderingEngine": {
      "label": "渲染引擎",
      "category": "渲染中",
      "enum": {
        "Html": "Html",
        "Mixed": "混合模式"
      }
    },
    "LinkTarget": {
      "label": "連結目標",
      "category": "渲染中"
    },
    "EndPage": {
      "label": "結束頁",
      "category": "雜項"
    },
    "AddTimestamp": {
      "label": "文件名稱追加時間戳",
      "category": "文件名稱"
    }
  }
}
