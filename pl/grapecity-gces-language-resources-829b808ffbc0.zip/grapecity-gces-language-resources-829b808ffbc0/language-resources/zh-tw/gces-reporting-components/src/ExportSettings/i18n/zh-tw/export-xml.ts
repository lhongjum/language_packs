export default {
  "friendlyName": "XML",
  "tooltipName": "XML 文件",
  "settings": {
    "Formatted": {
      "label": "格式",
      "category": "其他"
    },
    "WriteEmptyAttributes": {
      "label": "輸出空屬性",
      "category": "其他"
    },
    "OutputHiddenMatrixMembers": {
      "label": "輸出隱藏成員",
      "category": "其他"
    },
    "OutputTextboxConstantValues": {
      "label": "輸出文本框常量值",
      "category": "其他"
    },
    "DefaultDateFormat": {
      "label": "默認日期格式",
      "category": "其他"
    },
    "AddTimestamp": {
      "label": "文件名稱追加時間戳",
      "category": "文件名稱"
    }
  }
}
