import { PaperSize } from './common/PaperSize';

export default {
  "friendlyName": "Excel",
  "tooltipName": "Excel Book",
  "settings": {
    "UseCompression": {
      "label": "使用壓縮",
      "category": "雜項"
    },
    "OutputFormat": {
      "label": "OpenXml標準",
      "category": "雜項",
      "enum": {
        "OpenXmlTransitional": "Transitional",
        "OpenXmlStrict": "Strict"
      }
    },
    "EnableToggles": {
      "label": "啟用切換",
      "category": "雜項"
    },
    "Pagination": {
      "label": "分頁",
      "category": "雜項"
    },
    "UseDefaultPalette": {
      "label": "使用默認調色板",
      "category": "雜項"
    },
    "MultiSheet": {
      "label": "多頁",
      "category": "雜項"
    },
    "SheetName": {
      "label": "工作表名稱",
      "category": "雜項"
    },
    "ProtectedBy": {
      "label": "受保護",
      "category": "安全"
    },
    "WritePassword": {
      "label": "寫密碼",
      "category": "安全"
    },
    "ReadOnlyRecommended": {
      "label": "只讀推薦",
      "category": "安全"
    },
    "Orientation": {
      "label": "頁面方向",
      "category": "頁面設置",
      "enum": {
        "Default": "默認",
        "Portrait": "縱向",
        "Landscape": "橫向"
      }
    },
    "PaperSize": {
      "label": "紙張尺寸",
      "category": "頁面設置",
      "enum": PaperSize
    },
    "AddTimestamp": {
      "label": "文件名稱追加時間戳",
      "category": "文件名稱"
    }
  }
}
