export const reportingZH_TW: LanguageKeyValueMap = {

	// Designer
	drApplicationTitle: '報表',
	drYes: '確定',
	drNo: '取消',
	drUnsavedChangesTitle: '發現未保存的修改',
	drUnsavedChangesText: '當前文檔有未保存的修改，確認離開？ ',
	
	// Export Dialog
	edTextFormat: '導出格式',
	edTextParams: '報表參數',
	edTextExportParams: '導出參數',
	edTextReadyToExport: '可進行導出操作',
	edTextExport: '導出',
	edTextExportError: '導出錯誤',
	edTextExportTo: '導出為 {{type}}',
	edTextChooseExportFormat: '請選擇導出格式',
	edTextAdvancedSettings: '高級設置',
	
	edStatusTextGettingInfo: '加載報表信息...',
	edStatusTextInfoUnavailable: '沒有可用的報表信息',
	
	edHeaderParameters: '設置報表參數',
	edHeaderSettings: '導出設置',
	edExportBtnText: '導出',
	edNextBtnText: '下一步',
	edCancelBtnText: '取消',
	edCancelBtnTitle: '取消導出',

	// Template Wizard
	tpTagName: '報表模板',
	tpWizardTitle: '請選擇模板',
	tpWizardHeaderCategories: '文檔分類',
	tpWizardHeaderTemplates: '報表模板',
	tpWizardHeaderDetails: '詳細信息',
	tpWizardSearchPlaceholder: '請輸入模板名稱',
	tpWizardViewModeGallery: '磁貼視圖',
	tpWizardViewModeList: '列表視圖',
	tpCreateReport: '創建報表',
	tpCancel: '取消',
	tpSelectTemplateText: '請選中一個報表模板，以查看詳細說明',
	tpSelectCategoryText: '請選擇一個分類，以查看可用的報表模板',
	
	tpDetailsName: '報表模板名稱',
	tpDetailsDescription: '使用描述',
	tpDetailsCreated: '創建時間',
	tpDetailsCreatedBy: '創建者',
	tpDetailsModified: '更新時間',
	tpDetailsModifiedBy: '修改者',
	
	tpWizardBlankPage: '空白頁面報表',
	tpWizardBlankRDL: '空白RDL報表',
	
	sysTagNoCategory: '未分類',
	sysTagResources: '資源庫',
	sysTagFavorites: '收藏夾',
	sysTagImages: '圖片',
	sysTagThemes: '主題',
	pluginTemplates: '報表模板',
	
	// Saga
	sagaQueueErrorTaskFailed: '任務失敗',
	sagaQueueErrorExecFailed: '不能執行該任務',
	sagaQueueErrorNoWorkers: '沒有可用的任務執行者',
	sagaQueueErrorUnknown: '未知錯誤',
	
	sagaTaskStatusExporting: '正在將 {{doc}} 導出為 {{type}}',
	sagaTaskStarting: '啟動中...',
	
	sagaErrorExportFailed: '導出失敗',
	sagaErrorExportFailedDetails: '不能執行導出操作',
	sagaErrorExportFailedParams: '不能加載報表參數',
	sagaErrorExportFailedParamValues: '不能獲得參數值',
	
	sagaFail: '報表: 未知錯誤',
	
	sagaQueueErrorCaption: '執行隊列錯誤',
	sagaQueueError1Content: '任務被取消',
	sagaQueueError2Content: '任務處理失敗',
	sagaQueueError3Content: '未知的內部錯誤',
	sagaQueueError4Content: '沒有可用的工作線程',
	sagaQueueError5Content: '需要配置任務對應的訪問URL',
	
	updateTemplateListError: '更新報表模板列表失敗',
	
	// Document Types
	'report!name': '報表',
	'report!description': '報表',
	'template!name': '報表模板',
	'template!description': '報表模板',
	'masterReport!name': 'Master Report',
	'masterReport!description': 'Master Report',
	
	// Verbs
	'createReport!name': '創建報表',
	'createReport!description': '創建報表',
	
	'editReport!name': '編輯',
	'editReport!description': '編輯報表',
	
	'exportReport!name': '導出',
	'exportReport!description': '導出報表',
	
	'reportPreview!name': '預覽報表',
	'reportPreview!description': '預覽報表',
	
	'templatePreview!name': '預覽Html效果',
	'templatePreview!description': '將報表模板顯示為 Html 頁面，以便於預覽模板效果',
	
	'createReportWithTemplate!name': '創建報表',
	'createReportWithTemplate!description': '用當前模版創建報表',
	
	'copyAsTemplate!name': '複製為報表模板',
	'copyAsTemplate!description': '複製為報表模板文件',
	copyDocumentSuffix: '-模板',
	
	'editTemplate!name': '編輯',
	'editTemplate!description': '編輯報表',
	
	// Revision Verbs
	'previewRevision!name': '預覽',
	'previewRevision!description': '預覽報表的該版本',
	
	'editRevision!name': '編輯',
	'editRevision!description': '編輯報表的該版本',
	
	// Commands Dialog
	'commands!name': '工具欄選項/按鈕',
	'commands!description': '設置用戶可見的工具欄選項/按鈕',
	'commands!btnText': '編輯',
	'commandsEditor': '工具欄選項',
	'commandsEditorCurrent': '已選擇工具欄選項/按鈕',
	'commandsEditorNoCategoriesText': '還未選擇任何工具欄選項',
	'commandsEditorAvailableCategories': '可用選項',
	'commandsEditorNoAvailableCategories': '沒有可用的工具欄選項',
	'commands$navigation': '翻頁',
	'commands$refresh': '刷新',
	'commands$history': '前進後退',
	'commands$mousemode': '平移',
	'commands$zoom': '縮放',
	'commands$fullscreen': '全屏',
	'commands$print': '打印',
	'commands$singlepagemode': '單頁視圖',
	'commands$continuousmode': '多頁視圖',
	'commands$galleymode': '不分頁',
	'commands$pdf': 'PDF',
	'commands$excel': 'Excel',
	'commands$docx': 'Word',
	'commands$image': 'Image',
	'commands$html': 'HTML',
	'commands$csv': 'CSV',
	'commands$json': 'JSON',
	'commands$txt': 'TXT',
	'commands$xml': 'XML',

	saveCommandsError: '保存工具欄選項時出現錯誤',
	getCommandsError: '加載工具欄選項時出現錯誤',
	
	// Document Error Message
	documentNotDeleted: '無法刪除該文檔',
	documentUsedByAnother: '文檔\"{{docName}}\"被以下文檔所引用，無法直接刪除。 \n{{refDocNames}}',
	renameDocumentError: '重命名失敗',
	duplicateDocumentError: '複製文檔失敗',
	err_AccessDenied: '無法複製該文檔，因為你沒有編輯該文檔所引用資源的權限。 ',
	previewDocumentError: '預覽失敗',
	errorAccessDenied: '你沒有該文檔所引用資源的使用權限',
	
	// Reporting Plugin Exceptions
	reportingPluginUnknown: '報表任務執行過程中，發生了未知錯誤',
	reportingPluginLrt: '報表的長任務運行發生異常',
	reportingPluginBadResponse: '報表工作線程失去響應',
	reportingPluginStreaming: '報表工作線程進行流式傳輸過程中發生一個錯誤',
	reportingPluginResponseVerification: '報表工作線程在流式傳輸之後發生一個錯誤',
	
	// Worker Exceptions
	reportingWorkerExportInvalidParameters: '無效的報表參數',
	reportingWorkerExportUnknownRenderingExt: '不支持將報表導出為 {0} 格式',
	
	reportingWorkerTaskInitUnknown: '報表工作線程在執行以下任務時發生了未知錯誤: {0}',
	reportingWorkerTaskInitFileNotFound: '未找到文件 {0} ',
	reportingWorkerTaskInitUnableToLoadFile: '無法加載文件 {0}',
	
	reportingWorkerFailCheckInvalidParameters: '無效的報表參數',
	reportingWorkerFailCheckUnknown: '報表工作線程在執行以下任務時發生了未知錯誤: {0}',
	reportingWorkerFailCheckNoDataset: '未指定數據集',
	
	reportingWorkerRenderingDatasetNotFound: '無法加載指定的數據集，可能是因為訪問權限不足、或者文件不存在',
	reportingWorkerRenderingDatasourceNotFound: '無法加載指定的數據源，可能是因為訪問權限不足、或者文件不存在',
	reportingWorkerRenderingUnknown: '報表工作線程在執行以下任務時發生了未知錯誤: {0}',
	
	reportingWorkerReportUnknown: '在獲取以下報表基本信息時發生未知錯誤: {0}',
	reportingWorkerReportCyclicParameterReferences: '報表的參數之間存在循環引用，請檢查',

	// Document Section
	referencedDataDocuments: '引用的數據文檔',
	}
