﻿export const reportingZH_TW: LanguageKeyValueMap = { 

	// Tile 
	tTextNoWorkers: '無可用的工作線程', 
	tStatusIdle: '空閒', 

	tBtnTitleEnable: '啟用磁貼更新', 
	tBtnTitleDisable: '禁用磁貼更新', 

	// Tasks Tile 
	ttStatusTextInProgress: '處理中', 
	ttStatusTextComplete: '完成', 
	ttStatusTextInCancelled: '取消', 
	ttStatusTextInFailed: '失敗', 
	ttStatusTextInQueued: '排隊中', 

	ttTextNoDataAvailable: '沒有可用的數據', 

	// Saga 
	sagaErrorConnection: '連接錯誤', 
	sagaErrorConnectionDetails : '無法加載必須的數據', 

}
