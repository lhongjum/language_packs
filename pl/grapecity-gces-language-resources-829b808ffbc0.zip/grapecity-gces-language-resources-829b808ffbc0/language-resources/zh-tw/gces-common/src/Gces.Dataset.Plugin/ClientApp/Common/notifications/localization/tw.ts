export const ntfLocaleTW = {
    ntfDismiss: '忽略',
    ntfDismissAll: '忽略所有',
    ntfShowDetails: '顯示詳情',
    ntfShowAll: '顯示所有',
    ntfCancelTask: '取消這個任務',
};
