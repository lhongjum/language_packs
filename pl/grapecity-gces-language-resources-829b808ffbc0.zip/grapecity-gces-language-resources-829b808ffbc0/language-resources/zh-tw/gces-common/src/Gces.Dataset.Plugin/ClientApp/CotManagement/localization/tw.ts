export const portalTW: LanguageKeyValueMap = {
	'CotManagement!title': '數據集緩存',
	'CotManagement!description': '查看數據集緩存',
};

export const datasetTW: LanguageKeyValueMap = {
	'cot-title': '名稱',
	'cot-creator': '創建者',
	'cot-tenant': '組織',
	'cot-rowCount': '行數',
	'cot-operation': '狀態',
	'cot-lastUpdated': '最近更新時間',
	'cot-lastErrorCode': '最近結果',
	'cot-lastErrorData': '最近錯誤信息',
	'succeed': '成功',
	'failed': '失敗',
	'Standby': '成功',
	'Create': '創建中',
	'Overwrite': '重新創建中',
	'AppendData': '增量更新中',
	'Failed': '失敗',
	'onlyShowFailed': '只顯示失敗的數據集緩存',
	'noCotTip': '沒有匹配的數據集緩存',
	'emptyCot': '當前系統中沒有數據集緩存',
};