export const portalDataTW: LanguageKeyValueMap = {
	'smdsc!name': '語義模型',
	'smdsc!description': '語義模型',

	// Sidebar Share
	'psSemExecute!name': '執行',
	'psSemExecuteAndCreateDataset!name': '執行和創建數據集',
	'psSemReadWrite!name': '讀 / 寫',

	'createSemanticModel!name': '創建語義模型',
	'createSemanticModel!description': '創建語義模型',
	'editSemanticModel!name': '編輯...',
	'editSemanticModel!description': '編輯語義模型',

	'revert!name': '恢復',
	'revert!description': '恢復到這個版本',
	revertError: '模型恢復失敗',
	revertSuccess: '模型恢復成功',
	revertErrorMsg: '無法將模型還原為當前版本。 ',
	revertSuccessMsg: '模型已成功恢復為版本{{revision}}。 ',
};