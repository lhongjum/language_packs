export const mbLocaleTW = {
    OK: '確定',
    MessageBox: '消息提示',
};
