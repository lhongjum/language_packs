export const datasetTW: LanguageKeyValueMap = {
	UseConfigString: '使用配置連接字符串(高級)',
	err_10026: '獲取數據庫列表失敗。找不到或無法訪問服務器。請驗證您的設置並確保服務器允許遠程連接。如果連接仍然失敗，請手動輸入數據​​庫名稱或服務名稱。 ',
};