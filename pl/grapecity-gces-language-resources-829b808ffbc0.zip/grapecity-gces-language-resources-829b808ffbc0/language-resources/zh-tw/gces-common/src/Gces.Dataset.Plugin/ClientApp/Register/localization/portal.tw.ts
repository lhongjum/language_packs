
export const portalTW = {
	'createDataset!name': '創建數據集',
	'createDataset!description': '創建數據集',

	'createDatasource!name': '創建數據源',
	'createDatasource!description': '創建數據源',

	'dsc!name': '數據源',
	'dsc!description': '數據源',

	'dataset!name': '數據集',
	'dataset!description': '數據集',

	'modifyDataSource!name': '編輯...',
	'modifyDataSource!description': '編輯這個文檔',
	'reconfigDataSource!name': '重新配置',
	'reconfigDataSource!description': '重新配置這個文檔...',

	'modifyDataset!name': '編輯...',
	'modifyDataset!description': '編輯這個文檔',

	'refreshDataset!name': '刷新緩存...',
	'refreshDataset!description': '刷新緩存',

	'incrementalUpdateDataset!name': '增量更新緩存...',
	'incrementalUpdateDataset!description': '增量更新緩存',

	'copyDataset!name': '複製',
	'copyDataset!description': '複製這個文檔',

	'psExecute!name': '執行',
	'psExecuteAndCreateDataset!name': '執行和創建數據集',
	'appendData!name': '追加數據',
	'appendData!description': '為當前選擇的數據源追加數據',
};
