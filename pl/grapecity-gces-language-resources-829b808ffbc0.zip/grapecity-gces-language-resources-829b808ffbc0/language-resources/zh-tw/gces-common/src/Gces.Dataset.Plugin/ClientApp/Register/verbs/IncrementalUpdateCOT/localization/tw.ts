export const incrementalUpdateCotTW = {
	OK: '確定',
	Cancel: '取消',
	Close: '關閉',
	Yes: '是',
	No: '否',
	MessageBox: '消息提示',
	IncrementalUpdateDataSet: '增量更新數據集',
	IncrementalUpdating: '正在更新',
	IncrementalUpdateComplete: '增量更新完成',
	NoNeedIncrementalUpdate: '此数据集无需增量更新',
	IncrementalUpdateDatasetFailed: '增量更新數據集失敗',
	IncrementalUpdateDatasetConfirmMsg: '您是否要增量更新當前數據集的緩存？',
	DocumentInOperation: '文檔正在更新中，請稍後再試。 ',

	// update error
	err_100001: '非法參數: {{name}}。 ',
	err_100002: '服務器內部錯誤: {{message}}。 ',
	err_100009: '此文檔正在更新中。請稍後重試。 ',
	err_100012: '無效的用戶信息上下文: {{claimName}}.',
	err_100014: '您沒有權限訪問數據源"{{name}}"。 ',
	err_100015: '您沒有權限訪問該數據集所引用的數據源，或者被引用的數據源不存在。 ',
	err_100017: '“{{ptype}}”上的“{{key}}”值: “{{value}}”是無效的{{dtype}}值。 ',
	err_100018: '找不到此文檔。 ',
	err_100019: '您沒有權限訪問此文檔。 ',
	err_100021: '無法連接到此數據源 {{name}}。 ',
	err_100022: '您沒有更新此數據集的權限。',
	err_100023: '沒有可用的COT工作線程。',
	err_100018_desc: '找不到數據源 "{{ids}}"',
	err_400001: '請修改組織信息上下文參數"{{propertyName}}"設置。當前用戶所在的組織不存在該組織上下文參數。',

	// dataset manager error message
	'err_3000': '計算任務發生异常或計算任務被管理員取消。'
};
