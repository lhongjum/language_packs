export const parameterPanelZH: LanguageKeyValueMap = {
  // Parameters Panel
  paramPanelTextNoParameters: '该仪表板没有查询条件',
  hiddenParamsError: '该仪表板包含无效的隐藏参数',
  // Saga
  sagaValidationTextValueExpected: '必填',
  sagaValidationTextNoEmptyStrings: '不能为空',
  sagaValidationTextValidBoolean: '格式错误，需要布尔值',
  sagaValidationTextValidInteger: '格式错误，需要整数',
  sagaValidationTextValidFloat: '格式错误，需要浮点数',
  sagaValidationTextValidDateTime: '格式错误，需要日期时间',
  sagaValidationTextUnknownError: '未知错误',
  sagaValidationTextNoNull: '必填项',
  sagaValidationTextPickFromList: '请从列表中选择数据',
  sagaValidationTextMaxInteger: '数字值不能超过32位整数的最大值',
  // All Parameters
  paramsTextInvalidValue: '无效数据',
  // MultiValueParameter
  mvpTextAllValues: '全选',
  mvpTextSelectValue: '(请选择)',
  mvpTextSelectAll: '(全选)',
  mvpTextResetAll: '(重置)',
  // BooleanParameter
  bpTextTrue: '是',
  bpTextFalse: '否',
  // DropdownParameter
  ddpTextSelectValue: '(请选择)',
  ddpTextNull: '(空值)',
};