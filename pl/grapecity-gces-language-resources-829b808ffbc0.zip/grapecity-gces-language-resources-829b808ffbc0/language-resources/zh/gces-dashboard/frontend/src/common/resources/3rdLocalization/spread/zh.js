/* eslint-disable */

const zh = {
  //#region Spread Dialog
  title: "",
  defaultFont: "10pt Arial",
  ok: "确定",
  yes: "是",
  no: "否",
  apply: "应用",
  cancel: "取消",
  close: "关闭",

  customFormat: "用户设定",
  generalFormat: "标准",

  conditionalFormat: {
    highlightCellsRules: "单元格高亮规则",
    topBottomRules: "顶部/底部规则",
    dataBars: "数据条",
    colorScales: "配色",
    iconSets: "图标集",
    newRule: "新建规则...",
    clearRules: "清除规则...",
    manageRules: "管理规则...",

    greaterThan: "大于...",
    lessThan: "小于...",
    between: "介于...",
    equalTo: "等于...",
    textThatContains: "文本...",
    aDateOccurring: "日期...",
    duplicateValues: "重复值...",
    moreRules: "其他规则...",

    top10Items: "前10个项目...",
    bottom10Items: "后10个项目...",
    aboveAverage: "高于平均值...",
    belowAverage: "低于平均值...",

    gradientFill: "渐变填充",
    solidFill: "单色填充",
    directional: "方向",
    shapes: "图形",
    indicators: "指示",
    ratings: "评价",

    clearRulesFromSelectedCells: "清除选中单元格的格式化规则",
    clearRulesFromEntireSheet: "清除整个表格的格式化规则"
  },

  conditionalFormatting: {
    common: {
      'with': "格式",
      selectedRangeWith: "选择范围内的格式",
      and: "和"
    },
    greaterThan: {
      title: "大于",
      description: "为大于以下值的单元格设置格式："
    },
    lessThan: {
      title: "小于",
      description: "为小于以下值的单元格设置格式："
    },
    between: {
      title: "介于",
      description: "为介于以下值之间的单元格设置格式："
    },
    equalTo: {
      title: "等于",
      description: "为等于以下值的单元格设置格式："
    },
    textThatCotains: {
      title: "文本包含",
      description: "为包含以下文本的单元格设置格式："
    },
    dateOccurringFormat: {
      title: "发生日期",
      description: "为包含以下日期的单元格设置格式：",
      date: {
        yesterday: "昨天",
        today: "今天",
        tomorrow: "明天",
        last7days: "最近7 天",
        lastweek: "上周",
        thisweek: "本周",
        nextweek: "下周",
        lastmonth: "上个月",
        thismonth: "本月",
        nextmonth: "下个月"
      }
    },
    duplicateValuesFormat: {
      title: "重复值",
      description: "为包含以下类型值的单元格设置格式：",
      type: {
        duplicate: "重复",
        unique: "唯一"
      },
      valueswith: "值 格式"
    },
    top10items: {
      title: "前10项",
      description: "为值最大的那些单元格设置格式："
    },
    bottom10items: {
      title: "最后10项",
      description: "为值最小的那些单元格设置格式："
    },
    aboveAverage: {
      title: "高于平均值",
      description: "为高于平均值的单元格设置格式："
    },
    belowAverage: {
      title: "低于平均值",
      description: "为低于平均值的单元格设置格式："
    },
    newFormattingRule: {
      title: "新建格式化规则",
      title2: "编辑格式化规则",
      description1: "选择规则种类：",
      description2: "编辑规则描述：",
      ruleType: {
        formatOnValue: "►根据它们的值格式化所有的单元格",
        formatContain: "►只为包含以下内容的单元格设置格式",
        formatRankedValue: "►仅格式化排名靠前或靠后的单元格",
        formatAbove: "►仅格式化在平均值之上或是之下的单元格",
        formatUnique: "►仅格式化唯一值或重复值的单元格",
        useFormula: "►使用表达式来决定格式化的单元格"
      },
      formatOnValue: {
        description: "根据它们的值格式化所有的单元格：",
        formatStyle: "格式化样式：",
        formatStyleSelector: {
          color2: "双色",
          color3: "三色",
          dataBar: "数据条",
          iconSets: "图标集"
        },
        color2: {
          min: "最小值",
          max: "最大值",
          type: "类型：",
          value: "值：",
          color: "颜色",
          preview: "预览",
          minSelector: {
            lowest: "最低值"
          },
          maxSelector: {
            highest: "最高值"
          }
        },
        color3: {
          mid: "中间点"
        },
        dataBar: {
          showBarOnly: "仅显示数据条",
          auto: "自动",
          description2: "数据条外观：",
          fill: "填充",
          color: "颜色",
          border: "边框",
          fillSelector: {
            solidFill: "单色填充",
            gradientFill: "渐变填充"
          },
          borderSelector: {
            noBorder: "无边框",
            solidBorder: "实线边框"
          },
          negativeBtn: "负值与轴...",
          barDirection: "数据条的方向：",
          barDirectionSelector: {
            l2r: "从左至右",
            r2l: "从右至左"
          },
          preview: "预览",
          negativeDialog: {
            title: "负值与轴的设定",
            group1: {
              title: "负值数据条填充颜色",
              fillColor: "填充颜色：",
              apply: "将相同的颜色应用到正值数据条。"
            },
            group2: {
              title: "负值数据条边框颜色",
              borderColor: "边框颜色：",
              apply: "将相同的颜色应用到正值数据条"
            },
            group3: {
              title: "轴的设定",
              description: "选择单元格中的轴位置，以改变用于负值数据条的外观",
              radio: {
                auto: "自动（基于负值的可变位置显示）",
                cell: "单元格中点",
                none: "无（显示负值方向相同的方向）"
              },
              axisColor: "轴的颜色"
            }
          }
        },
        iconSets: {
          iconStyle: "图标样式：",
          showIconOnly: "仅显示图标",
          reverseIconOrder: "反向图标顺序",
          display: "依据这些规则显示每一个图标：",
          icon: "图标",
          value: "值",
          type: "类型",
          description1: "当值为",
          description2: "当 < ",
          operator: {
            largeOrEqu: ">=",
            large: ">"
          }
        },
        commonSelector: {
          num: "数字",
          percent: "百分比",
          formula: "公式",
          percentile: "百分位"
        }
      },
      formatContain: {
        description: "仅改变单元格：",
        type: {
          cellValue: "单元格的值",
          specificText: "指定文本",
          dateOccurring: "日期",
          blanks: "空白",
          noBlanks: "无空白",
          errors: "错误",
          noErrors: "无错误"
        },
        operator_cellValue: {
          between: "指定值之间",
          notBetween: "指定值之外",
          equalTo: "等于",
          notEqualTo: "不等于",
          greaterThan: "大于",
          lessThan: "小于",
          greaterThanOrEqu: "大于等于",
          lessThanOrEqu: "小于等于"
        },
        operator_specificText: {
          containing: "包含",
          notContaining: "不包含",
          beginningWith: "开始于",
          endingWith: "结束于"
        }
      },
      formatRankedValue: {
        description: "格式化排名的单元格：",
        type: {
          top: "顶部",
          bottom: "底部"
        }
      },
      formatAbove: {
        description: "格式化的单元格是：",
        type: {
          above: "之上",
          below: "之下",
          equalOrAbove: "等于或之上",
          equalOrBelow: "等于或之下",
          std1Above: "1 标准差以上",
          std1Below: "1 标准差以下",
          std2Above: "2 标准差以上",
          std2Below: "2 标准差以下",
          std3Above: "3 标准差以上",
          std3Below: "3 标准差以下"
        },
        description2: "选择范围的平均值"
      },
      formatUnique: {
        description: "格式化所有：",
        type: {
          duplicate: "重复的",
          unique: "唯一的"
        },
        description2: "选择范围内的值"
      },
      useFormula: {
        description: "格式化公式为真的值："
      },
      preview: {
        description: "预览:",
        buttonText: "格式化...",
        noFormat: "无格式设定",
        hasFormat: "AaBbCcYyZz"
      }
    },
    withStyle: {
      lightRedFill_DarkRedText: "浅红填充色深红色文本",
      yellowFill_DrakYellowText: "黄填充深黄色文本",
      greenFill_DarkGreenText: "绿填充深绿色文本",
      lightRedFill: "浅红色填充",
      redText: "红色文本",
      redBorder: "红色边框",
      customFormat: "自定义格式..."
    },
    exceptions: {
      e1: "您输入的值是无效的数字，日期，时间或字符串。",
      e2: "输入一个值。",
      e3: "输入1到1000之前的整数。",
      e4: "您输入的值不能为空。",
      e5: "这种类型的引用不能应用于条件格式化公式。\n变更为引用单个单元格或使用引用工作簿的方法，如 =SUM(A1:E5)。",
      e6: "公式规则的源范围仅能是单个范围！"
    }
  },

  formattingRulesManagerDialog: {
    title: "条件格式化规则管理",
    rulesScopeLabel: "当前工作簿的格式化规则：",
    rulesScopeForSelection: "当前选择范围",
    rulesScopeForWorksheet: "这个工作表格",
    newRule: "新建规则...",
    editRule: "编辑规则...",
    deleteRule: "删除规则...",
    gridTitleRule: "规则(应用于排序显示)",
    gridTitleFormat: "格式化",
    gridTitleAppliesTo: "应用于",
    gridTitleStopIfTrue: "条件满足的场合停止",
    ruleDescriptions: {
      valueBetween: '单元格的值在{0}和{1}的范围内',
      valueNotBetween: '单元格的值不在{0}和{1}的范围内',
      valueEquals: '单元格的值 = {0}',
      valueNotEquals: '单元格的值 <> {0}',
      valueGreateThan: '单元格的值 > {0}',
      valueGreateThanOrEquals: '单元格的值 >= {0}',
      valueLessThan: '单元格的值 < {0}',
      valueLessThanOrEquals: '单元格的值 <= {0}',
      valueContains: '单元格的值包含 "{0}"',
      valueNotContains: '单元格的值不包含 "{0}"',
      valueBeginsWith: '单元格的值开始于 "{0}"',
      valueEndsWith: '单元格的值结束于 "{0}"',
      last7Days: '过去 7 天内',
      lastMonth: '上个月',
      lastWeek: '上周',
      nextMonth: '下个月',
      nextWeek: '下周',
      thisMonth: '本月',
      thisWeek: '本周',
      today: '今天',
      tomorrow: '明天',
      yesterday: '昨天',
      duplicateValues: '重复的值',
      uniqueValues: '唯一的值',
      top: '前 {0}',
      bottom: '后 {0}',
      above: '平均值之上',
      above1StdDev: '1 标准差在平均值之上',
      above2StdDev: '2 标准差在平均值之上',
      above3StdDev: '3 标准差在平均值之上',
      below: '平均值之下',
      below1StdDev: '1 标准差在平均值之下',
      below2StdDev: '2 标准差在平均值之下',
      below3StdDev: '3 标准差在平均值之下',
      equalOrAbove: '等于或高于平均值',
      equalOrBelow: '等于或低于平均值',
      dataBar: '数据条',
      twoScale: '渐变色表',
      threeScale: '渐变色表',
      iconSet: '图标集',
      formula: '公式： {0}'
    },
    previewText: 'AaBbCcYyZz'
  },

  formatDialog: {
    title: "格式化单元格",
    fieldTitle: "格式化字段",
    chartTitle: "格式化图表",
    number: '数字',
    alignment: '对齐方式',
    font: '字体',
    border: '边框',
    fill: '填充',
    protection: '保护',
    category: '分类：',
    backColor: '背景色',
    textAlignment: '文本对齐方式',
    horizontalAlignment: '水平：',
    verticalAlignment: '垂直：',
    indent: '缩进：',
    textControl: '文本控制',
    wrapText: '折行',
    shrink: '缩小到合适',
    merge: '合并单元格',
    top: '顶部',
    bottom: '底部',
    left: '居左',
    right: '居右',
    center: '居中',
    general: '标准',
    sampleText: '文本',
    cantMergeMessage: '不能合并重叠范围。',
    lock: "锁定",
    lockComments: "在保护工作表（审阅选项卡、更改组、保护表按钮）之前，锁定单元格没有作用。",
    backGroundColor: "背景色：",
    moreColorsText: "更多颜色",
    noFillText: "无",
    sample: "示例"
  },

  borderDialog: {
    border: "边框",
    presets: "预置",
    none: "无",
    outline: "外框",
    inside: "内部",
    line: "线条",
    text: "文本",
    comments: "可以通过预置、预览图或其上方的按钮来应用选定的边框样式。"
  },

  colorPicker: {
    themeColorsTitle: "主题颜色",
    standardColorsTitle: "标准颜色",
    noFillText: "无",
    moreColorsText: "更多颜色...",
    colorDialogTitle: "颜色",
    red: "红： ",
    green: "绿： ",
    blue: "蓝： ",
    newLabel: "新增",
    currentLabel: "现在的颜色",
  },
  fontPicker: {
    familyLabelText: '字体：',
    styleLabelText: '字体样式：',
    sizeLabelText: '大小：',
    weightLabelText: '字体磅数：',
    colorLabelText: '颜色：',
    normalFontLabelText: '常规字体',
    previewLabelText: '预览',
    previewText: 'AaBbCcYyZz',
    effects: "效果",
    underline: "下划线",
    strikethrough: "删除线",

    fontFamilies: {
      Arial: "Arial",
      'Arial Black': "Arial Black",
      Calibri: "Calibri",
      Cambria: "Cambria",
      Candara: "Candara",
      Century: "Century",
      'Courier New': "Courier New",
      'Comic Sans MS': "Comic Sans MS",
      Garamond: "Garamond",
      Georgia: "Georgia",
      'Malgun Gothic': "Malgun Gothic",
      Mangal: "Mangal",
      Tahoma: "Tahoma",
      Times: "Times",
      'Times New Roman': "Times New Roman",
      'Trebuchet MS': "Trebuchet MS",
      Verdana: "Verdana",
      Wingdings: "Wingdings",
      Meiryo: "Meiryo",
      'MS Gothic': "MS Gothic",
      'MS Mincho': "MS Mincho",
      'MS PGothic': "MS PGothic",
      'MS PMincho': "MS PMincho"
    },
    fontStyles: {
      normal: '标准',
      italic: '斜体',
      oblique: '倾斜的'
    },
    fontWeights: {
      normal: '标准',
      bold: '#粗体',
      bolder: '加粗',
      lighter: '变细'
    },
  },
  borderPicker: {
    lineStyleTitle: '样式：',
    borderColorTitle: '颜色：',
  },
  categories: {
    general: "标准",
    numbers: "数字",
    currency: "货币",
    accounting: "会计",
    date: "日期",
    time: "时间",
    percentage: "百分比",
    fraction: "分数",
    scientific: "指数",
    text: "文本",
    special: "其它",
    custom: "自定义"
  },

  formatNumberComments: {
    generalComments: "一般格式单元格没有特定的数字格式。",
    numberComments: "数字格式用于显示一般的数字格式。货币和会计格式提供货币的专门格式化。",
    currencyComments: "货币格式化用于一般的货币格式。使用会计格式对列中的小数点进行对齐。",
    accountingComments: "会计格式排列货币符号及小数点到同一列。",
    dateComments: "日期格式显示日期和时间序列作为日期值。",
    timeComments: "时间格式显示日期和时间序列作为日期值。",
    percentageComments: "百分比格式将单元格的值乘以100，加上一个百分号显示格式化结果。",
    textComments: "文本格式将单元格的内容格式化为文本，如数字也会被显示为文本格式。单元格的内容与输入时一致。",
    specialComments: "其它格式对于跟踪列表和数据库值非常有用。",
    customComments: "输入数字格式化代码来使用一个已存在的代码作为开始的点。"
  },

  formatNumberPickerSetting: {
    type: "类型：",
    decimalPlaces: "小数位数：",
    symbol: "符号：",
    negativeNumber: "负值：",
    separator: "使用千分位(,)",
    deleted: "删除",
    locale: "地点(国家或地区)：",
    calendar: "日历种类："
  },

  localeType: {
    en_us: "英语（美国）",
    zh_cn: "中文"
  },

  calendarType: {
    western: "西历",
    // JER: "和历"
  },

  fractionFormats: [
    "# ?/?",
    "# ??/??",
    "# ???/???",
    "# ?/2",
    "# ?/4",
    "# ?/8",
    "# ??/16",
    "# ?/10",
    "# ??/100"
  ],

  numberFormats: [
    "0",
    "0;[Red]0",
    "0_);(0)",
    "0_);[Red](0)",
    "#,##0",
    "#,##0;[Red]#,##0",
    "#,##0_);(#,##0)",
    "#,##0_);[Red](#,##0)"
  ],

  dateFormats: [
    "m/d/yyyy",
    "[$-F800]dddd, mmmm dd, yyyy",
    "m/d;@",
    "m/d/yy;@",
    "mm/dd/yy;@",
    "[$-409]d-mmm;@",
    "[$-409]d-mmm-yy;@",
    "[$-409]dd-mmm-yy;@",
    "[$-409]mmm-yy;@",
    "[$-409]mmmm-yy;@",
    "[$-409]mmmm d, yyyy;@",
    "[$-409]m/d/yy h:mm AM/PM;@",
    "m/d/yy h:mm;@",
    "[$-409]mmmmm;@",
    "[$-409]mmmmm-yy;@",
    "m/d/yyyy;@",
    "[$-409]d-mmm-yyyy;@"
  ],

  chinaWesternDateFormat: [
    "yyyy-mm-dd;@",
    "[DBNum1][$-804]yyyy年m月d日;@",
    "[DBNum1][$-804]yyyy年m月;@",
    "[DBNum1][$-804]m月d日;@",
    "yyyy年m月d日;@",
    "yyyy年m月;@",
    "m月d日;@",
    "[$-804]aaaa;@",
    "[$-804]aaa;@",
    "yyyy/m/d;@",
    "[$-409]yyyy/m/d h:mm AM/PM;@",
    "yyyy/m/d h:mm;@",
    "m/d/yy;@",
    "m/d;@",
    "mm/dd/yy;@",
    "[$-409]d-mmm;@",
    "[$-409]d-mmm-yy;@",
    "[$-409]dd-mmm-yy;@",
    "[$-409]mmm-yy;@",
    "[$-409]mmmm-yy;@",
    "[$-409]mmmmm;@",
    "[$-409]mmmmm-yy;@"
  ],

  japanEmperorReignDateFormat: [
    "[$-411]ge.m.d;@",
    "[$-411]ggge'年'm'月'd'日';@"
  ],

  timeFormats: [
    "[$-F400]h:mm:ss AM/PM",
    "h:mm;@",
    "[$-409]h:mm AM/PM;@",
    "h:mm:ss;@",
    "[$-409]h:mm:ss AM/PM;@",
    "mm:ss.0;@",
    "[h]:mm:ss;@",
    "[$-409]m/d/yy h:mm AM/PM;@",
    "m/d/yy h:mm;@"
  ],

  chinaTimeFormats: [
    "h:mm;@",
    "[$-409]h:mm AM/PM;@",
    "h:mm:ss;@",
    "[$-409]h:mm:ss AM/PM;@",
    "上午/下午h时mm分;@",
    "上午/下午h时mm分ss秒;@",
    "[DBNum1][$-804]h时mm分;@",
    "[DBNum1][$-804]上午/下午h时mm分;@",
  ],

  textFormats: [
    "@"
  ],

  specialFormats: [
    "00000",
    "00000-0000",
    "[<=9999999]###-####;(###) ###-####",
    "000-00-0000"
  ],

  specialChinaFormats: [
    "000000",
    "[DBNum1][$-804]General",
    "[DBNum2][$-804]General"
  ],

  currencyFormats: [
    "#,##0",
    "#,##0;[Red]#,##0",
    "#,##0;-#,##0",
    "#,##0;[Red]-#,##0"
  ],

  percentageFormats: [
    "0%"
  ],

  scientificFormats: [
    "0E+00"
  ],

  accountingFormats: [
    "_(* #,##0_);_(* (#,##0);_(* \"-\"_);_(@_)"
  ],

  customFormats: [
    "General",
    "0",
    "0.00",
    "#,##0",
    "#,##0.00",
    "#,##0;(#,##0)",
    "#,##0;[Red](#,##0)",
    "#,##0.00;(#,##0.00)",
    "#,##0.00;[Red](#,##0.00)",
    "$#,##0;($#,##0)",
    "$#,##0;[Red]($#,##0)",
    "$#,##0.00;($#,##0.00)",
    "$#,##0.00;[Red]($#,##0.00)",
    "0%",
    "0.00%",
    "0.00E+00",
    "##0.0E+0",
    "# ?/?",
    "# ??/??",
    "m/d/yyyy",
    "d-mmm-yy",
    "d-mmm",
    "mmm-yy",
    "h:mm AM/PM",
    "h:mm:ss AM/PM",
    "hh:mm",
    "hh:mm:ss",
    "m/d/yyyy hh:mm",
    "mm:ss",
    "mm:ss.0",
    "@",
    "[h]:mm:ss",
    "$ #,##0;$ (#,##0);$ \"-\";@",
    " #,##0; (#,##0); \"-\";@",
    "$ #,##0.00;$ (#,##0.00);$ \"-\"??;@",
    " #,##0.00; (#,##0.00); \"-\"??;@",
    "hh:mm:ss",
    "00000",
    "# ???/???",
    "000-00-0000",
    "[$-4]dddd, mmmm dd, yyyy",
    "m/d;@",
    "[<=9999999]###-####;(###) ###-####",
    "# ?/8"
  ],

  accountingSymbol: [
    ["None", null, null],
    ["¥", "", "ja-JP"],
    ["$", "", "en-US"],
  ],

  specialType: [
    "邮政编码",
    "Zip Code + 4",
    "电话号码",
    "社会保障编号"
  ],

  specialChinaType: [
    "邮政编码",
    "中文小写数字",
    "中文大写数字",
  ],

  fractionType: [
    "增加1位数 (1/4)",
    "增加2位数 (21/25)",
    "增加3位数 (312/943)",
    "分母设定为2 (1/2)",
    "分母设定为4 (2/4)",
    "分母设定为8 (4/8)",
    "分母设定为16 (8/16)",
    "分母设定为10 (3/10)",
    "分母设定为100 (30/100)"
  ],

  negativeNumbers: {
    "-1234.10": "-1234.10",
    "red:1234.10": "1234.10",
    "(1234.10)": "(1234.10)",
    "red:(1234.10)": "(1234.10)"
  },

  currencyNegativeNumbers: {
    "number1": "-1,234.10",
    "red:number2": "1,234.10",
    "number3": "-1,234.10",
    "red:number4": "-1,234.10"
  },

  insertFunctionDialog: {
    title: "插入方法",
    functionCategory: "函数分类：",
    functionList: "函数列表：",
    formula: "公式：",
    functionCategorys: "全部，数据库，日期/时间，工程，，财务，信息，逻辑，查找和引用，数学和三角，统计，文本",
  },
  //#endregion

};
export default zh;
