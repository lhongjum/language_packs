export const portalZH: LanguageKeyValueMap = {
  'dbd!name': '仪表板',
};
