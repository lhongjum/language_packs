export const portalZH: LanguageKeyValueMap = {
  'shortcut-dashboards!description': '',
  'shortcut-dashboards!props!text': '仪表板',
  'shortcut-dashboards!title': '仪表板磁贴',

  'dashboardsConfiguration!title': '仪表板设置',
  'dashboardsConfiguration!description': '仪表板功能相关的设置选项',
  'dashboardsConfiguration!containerFilterScope': '容器过滤范围',
  'dashboardsConfiguration!containerFilterScope!Container': '当前容器',
  'dashboardsConfiguration!containerFilterScope!Global': '整个页面',
  'dashboardsConfiguration!maxAggregatedDataPoints': '聚合数据点上限值',
  'dashboardsConfiguration!enableDeveloperMode': '启用开发者模式',
};
