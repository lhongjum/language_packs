export const portalResourceZH: LanguageKeyValueMap = {
	'set-configuration!name': '设置参数',
	'set-configuration!description': '设置参数',
	'rename-visual!name': '重命名文档',
	'rename-visual!description': '重命名文档',
};

export const shareResourceZH: LanguageKeyValueMap = {
	'setConfiguration': '设置参数',
	'noConfiguration': '没有可用参数',
	'rename': '重命名',
	'isTrusted': '信任该插件',
	'switchTrue': '是',
	'switchFalse': '否',
};