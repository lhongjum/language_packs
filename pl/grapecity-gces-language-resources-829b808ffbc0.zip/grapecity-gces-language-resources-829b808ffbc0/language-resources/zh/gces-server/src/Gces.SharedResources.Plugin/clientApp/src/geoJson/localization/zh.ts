export const portalResourceZH: LanguageKeyValueMap = {
  'shortcut-categories!description': '',
  'shortcut-categories!props!text': '门户目录',
  'shortcut-categories!title': '门户目录磁贴',
  'geojson-storge-management!title': '地图信息',
  'geojson-storge-management!description': 'GeoJson 管理',
  'shortcut-themes!description': '',
  'shortcut-themes!props!text': '主题',
  'shortcut-themes!title': '主题磁贴',
  'shortcut-image!description': ' ',
  'shortcut-image!props!text': '图片',
  'shortcut-image!title': '图片磁贴',
  'rename-geo!name': '重命名文档',
  'rename-geo!description': '重命名文档'
};

export const shareResourceZH: LanguageKeyValueMap = {
  // Header
  headerItemTextUploadNew: '上传文档',
  headerItemHeaderAddNew: '新建文档',
  headerItemTextAdminPortal: '系统管理',
  headerItemTextLogout: '退出登录',
  repeatName: '文档({{newName}}) 已经存在',
  renameDocNotFound: '文档找不到(可能已被移除，请刷新当前页)',
  noRenameDocPermission: '没有权限重命名当前文档',

  // Upload Dialog
  udTextFiles: '{{count}} 个文件',
  udTextFiles_plural: '{{count}} 个文件',

  udTitleUpload: '上传文档',
  udTitleUploading: '正在上传...',

  udTextStatusNoFiles: '没有选择任何文件',
  udTextStatusInitializing: '初始化...',
  udTextStatusInProgress: '已经上传 {{total}} 个中的 {{count}} 个文档',

  udTextStatusReadyToCommitPartial: '准备提交 {{total}} 个中的 {{countText}}',
  udTextStatusReadyToCommit: '验证完毕，可以提交',

  udHeaderInvalid: '无效的文档',
  udHeaderUnresolved: '未识别的文档',
  udHeaderAlreadyExists: '已存在的文档(请选择上传方式)',
  udHeaderReadyToCommit: '新上传的文档',
  udHeaderUploading: '正在上传',

  udBtnTextCommit: '提交',
  udBtnTextCommitValidOnly: '仅上传有效文档',
  udBtnTextCancel: '取消',

  udDNDTextDropFiles: '拖拽文档到这里',
  udDNDTextClickHere: '或者点击这里去选择文档',

  // Upload File Item
  ufiTextUploading: '正在上传...',
  ufiBtnTitleKeepBoth: '作为新文档上传',
  ufiBtnTitleOverwrite: '覆盖现有同名的文档',

  // Upload Saga
  usErrorTextSessionError: '上传会话错误',
  usErrorTextValidationError: '验证',
  usErrorTextValidationErrorDetails: '抱歉! 我们不能得到有效的状态。',
  usErrorTextUploadCommitError: '上传错误',
  usErrorTextUploadCommitErrorDetails: '抱歉！我们不能上传。',
  usErrorTextCancelationError: '抱歉！我们不能取消这个正在上传的文件。',

  // Upload Other
  uoTextUnknownFileType: '未知的文档类型',
  uoTextUnsupportedFileType: '不支持的文档类型',

  rename: '重命名',
  untitled: '未命名',
  save: '保存',
  cancel: '取消',
  name: '名称',
  description: '描述',
  OK: '确定',
  Close: '关闭',
  messageBox: '消息提示',
  hierarchyEditorTitle: 'Hierarchy 编辑器',
  geoJsonSearchPlaceHolder : '查找 geojson',
  noGeoJsonTip: '没有Geojson数据，请先上传数据',
  noGeoJsonMatchTip: '没有匹配的Geojson',
  dropGeojsonHere: '拖拽geojson到当前区域',
  joinTitle: '连接',
  equals: '等于',
  joinTo: '连接到',
  joinInfo: '选择左表“{{leftTableTitle}}”的属性名及值连接到右表“{{rightTableTitle}}”',
  error_300000: '未知错误!',
  error_300001: '文档已经存在!',
  error_300002: '该文档正被其他文档引用!',
  error_300003: '无法访问该文档!',
  error_300004: '文档格式不合法!',
  error_300005: '文档已被移除!',
  error_300006: '文档不存在!',

  UnknowError: '未知错误!',
};
