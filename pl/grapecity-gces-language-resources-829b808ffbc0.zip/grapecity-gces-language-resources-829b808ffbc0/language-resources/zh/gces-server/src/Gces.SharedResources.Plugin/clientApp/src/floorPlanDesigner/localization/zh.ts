﻿export const portalResourceZH: LanguageKeyValueMap = {
	'createFloorPlan!name': '创建自定义地图',
	'createFloorPlan!description': '创建一个新的自定义地图',
	'modifyFloorPlan!name': '编辑...',
	'modifyFloorPlan!description': '编辑这个自定义地图',
	'floorPlan!name': '自定义地图',
};

export const shareResourceZH: LanguageKeyValueMap = {

};

export const designerResourceZH: LanguageKeyValueMap = {
	// common
	FloorPlanDesigner: '自定义地图设计器',
	Save: '保存',
	Untitled: '未保存',
	Apply: '应用',
	Cancel: '取消',
	Yes: '是',
	No: '否',
	OK: '确定',
	Close: '关闭',
	EditName: '编辑名字',
	Name: '名字',
	Description: '修改说明',
	actionBar_importImage: '导入图片',
	actionBar_path: '路径',
	actionBar_rect: '矩形',
	actionBar_ellipsis: '椭圆',
	actionBar_zoomIn: '放大',
	actionBar_zoomOut: '缩小',
	actionBar_name: '名称',
	menuItem_rename: '重命名',
	menuItem_delete: '删除',
	menuItem_delete_shortCut: 'BACKSPACE',
	menuItem_group: '组合',
	menuItem_group_shortCut: 'G',
	menuItem_unGroup: '取消组合元素',
	menuItem_unGroup_shortCut: 'G',
	menuItem_removeBgImage: '删除图片',
	areaNamePattern: '形状{{number}}',
	areaNameRegex: '^形状(\\d+)$',
	'preview-floorPlan!title': '预览自定义地图',

	Confirmation: '发现未保存的修改',
	CloseFloorPlanDesignerConfirm: '当前文档有未保存的修改，确认离开？',

	// error info
	EmptyName: '名称为空',
	AreaNameExist: '“{{name}}”已经存在。',
	FloorPlanSaveError: '自定义地图保存失败',
	PleaseInputName: '请输入自定义地图名称。',
	FloorPlanNameOnlySapcesError: '自定义地图名称非法。 \n请不要只使用空格作为自定义地图名称。',
	FloorPlanGraphEmptyError: '自定义地图图形不能为空。',
	updateFloorError: '更新自定义地图失败',
	loadFloorError: '加载自定义地图失败',
	createFloorError: '添加自定义地图失败',
	err_300000: '发生未知错误，错误信息：{{message}}',
	err_300001: '文档“{{Title}}”已经存在。',
	err_300002: '该文档被其它文档引用。',
	err_300003: '没有权限访问该文档。',
	err_300004: '检测到非法参数。',
	err_300005: '文档已经被删除。',
	err_300006: '文档不存在。',
	err_300007: '文档名称不能为空。',
};
