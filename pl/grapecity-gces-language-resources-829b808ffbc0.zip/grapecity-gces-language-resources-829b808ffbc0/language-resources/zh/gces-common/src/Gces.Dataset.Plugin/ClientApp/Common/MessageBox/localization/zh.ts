export const mbLocaleZH = {
    OK: '确定',
    MessageBox: '消息提示',
};
