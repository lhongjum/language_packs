export const refreshCotZH = {
	OK: '确定',
	Cancel: '取消',
	Close: '关闭',
	Yes: '是',
	No: '否',
	MessageBox: '消息提示',
	RefreshDataSet: '刷新数据集',
	Refreshing: '正在刷新',
	RefreshComplete: '刷新完成',
	NoNeedRefresh: '此数据集无需刷新',
	RefreshDatasetFailed: '刷新数据集失败',
	RefreshDatasetConfirmMsg: '您是否要刷新当前数据集的缓存？',
	DocumentInOperation: '文档正在更新中，请稍后再试。',

	// update error
	err_100001: '非法参数: {{name}}。',
	err_100002: '服务器内部错误: {{message}}。',
	err_100009: '此文档正在更新中。请稍后重试。',
	err_100012: '无效的用户信息上下文: {{claimName}}.',
	err_100014: '您没有权限访问数据源"{{name}}"。',
	err_100015: '您没有权限访问该数据集所引用的数据源，或者被引用的数据源不存在。',
	err_100017: '“{{ptype}}”上的“{{key}}”值: “{{value}}”是无效的{{dtype}}值。',
	err_100018: '找不到此文档。',
	err_100019: '您没有权限访问此文档。',
	err_100021: '无法连接到此数据源 {{name}}。',
	err_100022: '您没有更新此数据集的权限。',
	err_100023: '没有可用的COT工作线程。',
	err_100018_desc: '找不到数据源 "{{ids}}"',
	err_400001: '请修改组织信息上下文参数"{{propertyName}}"设置。当前用户所在的组织不存在该组织上下文参数。',

	// dataset manager error message
	'err_3000': '计算任务发生异常或计算任务被管理员取消。'
};
