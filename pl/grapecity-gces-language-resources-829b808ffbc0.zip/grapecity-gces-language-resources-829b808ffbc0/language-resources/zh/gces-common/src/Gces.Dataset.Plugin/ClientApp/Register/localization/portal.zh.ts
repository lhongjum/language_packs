
export const portalZH = {
	'createDataset!name': '创建数据集',
	'createDataset!description': '创建数据集',

	'createDatasource!name': '创建数据源',
	'createDatasource!description': '创建数据源',

	'dsc!name': '数据源',
	'dsc!description': '数据源',

	'dataset!name': '数据集',
	'dataset!description': '数据集',

	'modifyDataSource!name': '编辑...',
	'modifyDataSource!description': '编辑这个文档',
	'reconfigDataSource!name': '重新配置',
	'reconfigDataSource!description': '重新配置这个文档...',

	'modifyDataset!name': '编辑...',
	'modifyDataset!description': '编辑这个文档',

	'refreshDataset!name': '刷新缓存...',
	'refreshDataset!description': '刷新缓存',

	'incrementalUpdateDataset!name': '增量更新缓存...',
	'incrementalUpdateDataset!description': '增量更新缓存',

	'copyDataset!name': '复制',
	'copyDataset!description': '复制这个文档',

	'psExecute!name': '执行',
	'psExecuteAndCreateDataset!name': '执行和创建数据集',
	'appendData!name': '追加数据',
	'appendData!description': '为当前选择的数据源追加数据',
};
