export const datasetZH: LanguageKeyValueMap = {
	UseConfigString: '使用配置连接字符串(高级)',
	err_10026: '获取数据库列表失败。找不到或无法访问服务器。请验证您的设置并确保服务器允许远程连接。如果连接仍然失败，请手动输入数据库名称或服务名称。',
};
