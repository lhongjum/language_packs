export const ntfLocaleZH = {
    ntfDismiss: '忽略',
    ntfDismissAll: '忽略所有',
    ntfShowDetails: '显示详情',
    ntfShowAll: '显示所有',
    ntfCancelTask: '取消这个任务',
};
