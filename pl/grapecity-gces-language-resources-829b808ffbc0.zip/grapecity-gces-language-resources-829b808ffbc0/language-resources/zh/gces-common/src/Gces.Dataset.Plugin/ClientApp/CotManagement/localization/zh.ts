export const portalZH: LanguageKeyValueMap = {
	'CotManagement!title': '数据集缓存',
	'CotManagement!description': '查看数据集缓存',
};

export const datasetZH: LanguageKeyValueMap = {
	'cot-title': '名称',
	'cot-creator': '创建者',
	'cot-tenant': '组织',
	'cot-rowCount': '行数',
	'cot-operation': '状态',
	'cot-lastUpdated': '最近更新时间',
	'cot-lastErrorCode': '最近结果',
	'cot-lastErrorData': '最近错误信息',
	'succeed': '成功',
	'failed': '失败',
	'Standby': '成功',
	'Create': '创建中',
	'Overwrite': '重新创建中',
	'AppendData': '增量更新中',
	'Failed': '失败',
	'onlyShowFailed': '只显示失败的数据集缓存',
	'noCotTip': '没有匹配的数据集缓存',
	'emptyCot': '当前系统中没有数据集缓存',
};