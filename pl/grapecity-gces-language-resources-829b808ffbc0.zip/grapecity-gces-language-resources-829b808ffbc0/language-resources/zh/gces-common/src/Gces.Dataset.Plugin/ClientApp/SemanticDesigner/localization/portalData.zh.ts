export const portalDataZH: LanguageKeyValueMap = {
	'smdsc!name': '语义模型',
	'smdsc!description': '语义模型',

	// Sidebar Share
	'psSemExecute!name': '执行',
	'psSemExecuteAndCreateDataset!name': '执行和创建数据集',
	'psSemReadWrite!name': '读 / 写',

	'createSemanticModel!name': '创建语义模型',
	'createSemanticModel!description': '创建语义模型',
	'editSemanticModel!name': '编辑...',
	'editSemanticModel!description': '编辑语义模型',

	'revert!name': '恢复',
	'revert!description': '恢复到这个版本',
	revertError: '模型恢复失败',
	revertSuccess: '模型恢复成功',
	revertErrorMsg: '无法将模型还原为当前版本。',
	revertSuccessMsg: '模型已成功恢复为版本{{revision}}。',
};
