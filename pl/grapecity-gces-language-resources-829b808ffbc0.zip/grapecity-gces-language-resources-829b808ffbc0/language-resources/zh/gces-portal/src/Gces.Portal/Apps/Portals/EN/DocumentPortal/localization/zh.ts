export const portalZH: LanguageKeyValueMap = {
	// common
	close: '关闭',
	more: '更多...',

	// Nav APP
	naServerIsUnavailable: '服务器不能访问，请检查网络连接是否正常。',
	naFetchDocumentsFailed: '获取文档列表失败。',
	naNoPluginsFound: '未发现任何插件',

	// Favorites
	naDashboard: '仪表板',
	naReport: '报表',

	// Tags
	naTagNoCategory: '未分类',

	// Workspace
	wsDocuments: '文档列表',
	wsDocTitleName: '名称: {{name}}',
	wsDocTitleDescription: '\n文档描述: {{description}}',
	// Tags editor
	tagsEditorCategories: '管理分类',
	tagsEditorCurrent: '已选分类',
	tagsEditorNoCategoriesText: '未设置任何分类',
	tagsEditorAvailableCategories: '可选分类',
	tagsEditorNoAvailableCategories: '没有可选的分类',
	assignCategoryError: '指定文档分类失败',

	// Sidebar
	sidebarGetRolesFailed: '获取角色信息失败',
	'doc-revisions!name': '修订历史',
	'doc-revisions!description': '',
	'doc-info!name': '基本信息',
	'doc-info!description': '',
	docInfoNoComment: '没有描述',
	commentWithVersion: '版本 {{no}}: {{comment}}',

	// Document Verbs
	'copyReport!name': '复制',
	'copyReport!description': '复制这个文档',
	'copyDashboard!name': '复制',
	'copyDashboard!description': '复制这个文档',
	copyDocumentSuffix: '-副本',
	duplicateDocumentError: '复制文档失败',
	duplicateDocumentSuccess: '复制文档成功',

	// Tool bar
	search: '搜索',
	searchInSelected: '在选中的分类中搜索',
	searchInAll: '在所有分类中搜索',
	'searchInfo!Selected': '在{{category}}中搜索',
	'searchInfo!All': '在所有分类中搜索',
};
