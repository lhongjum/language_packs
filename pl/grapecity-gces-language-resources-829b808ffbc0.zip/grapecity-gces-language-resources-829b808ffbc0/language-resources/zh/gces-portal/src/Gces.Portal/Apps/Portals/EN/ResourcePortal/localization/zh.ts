export const portalZH: LanguageKeyValueMap = {
	// Common
	Logo: 'Logo',
	Avatar: '头像',
	Expand: '展开',
	Collapse: '折叠',
	More: '更多...',

	// Nav APP
	naData: '数据',
	naDocuments: '文档',
	naOther: '其他',
	naCreate: '创建',
	naLogout: '退出登录',
	naDocumentPortal: '文档门户',
	naResourcePortal: '资源门户',
	naAdminPortal: '系统管理',
	naFetchDocumentsFailed: '获取文档列表失败。',

	// Upload
	naUploading: '上传文件',
	naCommit: '提交',
	naCancel: '取消',
	naClose: '关闭',
	naReadyToCommit: '可以提交的文档',
	naInvalidFiles: '无效的文档',
	naUnresolvedFiles: '不能上传的文档',
	naReferenceUnresolvedFiles: '缺少引用的文档',
	naUploading2: '正在上传的文档',
	naAlreadyExists: '已存在的文档',
	ufiBtnTitleKeepBoth: '作为新文档上传',
	ufiBtnTitleOverwrite: '覆盖现有同名的文档',
	usErrorTextSessionError: '上传会话错误',
	usErrorTextValidationError: '验证',
	usErrorTextValidationErrorDetails: '抱歉，获取验证结果有效状态失败。',
	usErrorTextUploadCommitError: '上传错误',
	usErrorTextUploadCommitErrorDetails: '抱歉，上传文档失败。',
	usErrorTextCancellationError: '抱歉，无法取消正在上传的文档。',

	// Drop Zone
	dzDragDrop: '拖放',
	dzFiles: '文件到这里',
	dzClickToSelect: '或者点击这里选择文件',
	dzUpload: '上传',

	// Sidebar
	sidebarGetRolesFailed: '获取角色信息失败',
	'doc-revisions!name': '修订历史',
	'doc-revisions!description': '',
	'doc-info!name': '基本信息',
	'doc-info!description': '',
	docInfoNoComment: '没有描述',
	commentWithVersion: '版本 {{no}}: {{comment}}',
	infoPanelDescriptionPlaceholder: '请输入文档描述',

	// InfoTabSection
	'themePreview!name': '预览',
	'imagePreview!name': '预览',

	// Document Verbs
	'copyReport!name': '复制',
	'copyReport!description': '复制这个文档',
	'copyDashboard!name': '复制',
	'copyDashboard!description': '复制这个文档',
	'copySemanticModel!name': '复制...',
	'copySemanticModel!description': '复制这个文档',
	copyDocumentSuffix: '-副本',
	duplicateDocumentError: '复制文档失败',
	duplicateDocumentSuccess: '复制文档成功',

	// image preview tab
	'image-preview!name': '预览',
	'image-preview!description': '预览图片',

	// theme preview tab
	'theme-preview!name': '预览',
	'theme-preview!description': '预览主题',
	wsDocTitleName: '名称: {{name}}',
	wsDocTitleDescription: '\n文档描述: {{description}}',

};
