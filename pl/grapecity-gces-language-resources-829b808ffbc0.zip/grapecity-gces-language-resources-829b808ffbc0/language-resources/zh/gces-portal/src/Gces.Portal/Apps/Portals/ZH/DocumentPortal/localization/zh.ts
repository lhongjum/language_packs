export const portalZH: LanguageKeyValueMap = {
	// Common
	more: '更多...',

	// Loader
	layoutGettingReady: '正在为您准备文档列表，请稍等...',
	layoutPortCanNotStart: '服务未能启动，请与管理员联系...',

	// System Tags
	sysTagNoCategory: '未分类',
	sysTagResources: '资源库',
	sysTagFavorites: '收藏夹',
	sysTagImages: '图片',
	sysTagThemes: '主题',
	sysTagFloorPlans: '自定义地图',

	// Plugin Tags
	pluginDataset: '数据集',
	pluginDataSource: '数据源',
	pluginSemanticModel: '语义模型',
	pluginTemplates: '报表模板',
	pluginMasters: '母版报表',

	// Notifications
	ntfDismiss: '忽略',
	ntfDismissAll: '忽略所有',
	ntfShowDetails: '显示详情',
	ntfShowAll: '显示所有',
	ntfCancelTask: '取消这个任务',

	// Documents View
	docViewHeaderCategories: '文档分类',
	docViewHeaderDocuments: '文档列表',
	docViewDocsCount: '{{count}} 个文档',
	docViewDocsCount_plural: '{{count}} 个文档',

	// Expanded Documents View
	docViewExpHeaderCategories: '$t(docViewHeaderCategories)',
	docViewExpHeaderDocuments: '$t(docViewHeaderDocuments)',
	docViewExpHeaderDetails: '详细信息',

	// Permissions
	psPermissions: '访问权限',
	psShare: '分享管理',
	psNoSharing: '该文档没有被分享',
	'psExecute!name': 'Execute',
	'psRead!name': '只读',
	'psReadWrite!name': '读写',
	psCancel: '取消',
	psSave: '保存',

	// Command Bar
	cbCritName: '名称',
	cbCritType: '类型',
	cbCritDateUpdated: '更新时间',
	cbCritDateCreated: '创建时间',
	cbSort: '排序',
	cbFilterByDocumentType: '按文档类型过滤',
	cbSearch: '搜索',

	cbViewModeList: '列表',
	cbViewModeTree: '树形',
	cbTitleSwitchViewMode: '切换为{{mode}}菜单',
	cbPersonalTagManagement: '管理个人分类',

	cbLayoutModeDefault: '浏览',
	cbLayoutModeExpanded: '管理',
	cbTitleSwitchLayoutMode: '切换为文档{{mode}}视图',

	// Header
	headerItemTextUploadNew: '上传文档',
	headerItemHeaderAddNew: '新建文档',
	headerItemTextAdminPortal: '系统管理',
	headerItemTextLogout: '退出登录',
	headerCategoriesAndDocuments: '文档分类',

	// Main Menu
	menuExpand: '展开菜单 ',
	menuCollapse: '折叠菜单',

	// Nav
	navFavorites: '收藏夹',
	navCategories: '分类',

	// nav org
	globalOrgName: '全局组织',
	switchOrganization: '切换组织',
	editProfileSetting: '编辑个人配置',

	// Upload Dialog
	udTextFiles: '{{count}} 个文件',
	udTextFiles_plural: '{{count}} 个文件',

	udTitleUpload: '上传文档',
	udTitleUploading: '正在上传...',

	udTextStatusNoFiles: '没有选择任何文件',
	udTextStatusInitializing: '初始化...',
	udTextStatusInProgress: '已经上传 {{total}} 个中的 {{count}} 个文档',

	udTextStatusReadyToCommitPartial: '准备提交 {{total}} 个中的 {{countText}}',
	udTextStatusReadyToCommit: '验证完毕，可以提交',

	udHeaderInvalid: '无效的文档',
	udHeaderUnresolved: '不能上传的文档',
	udHeaderReferenceUnresolved: '缺少引用的文档',
	udHeaderAlreadyExists: '已存在的文档(请选择上传方式)',
	udHeaderReadyToCommit: '新上传的文档',
	udHeaderUploading: '正在上传',

	udBtnTextCommit: '提交',
	udBtnTextCancel: '取消',
	udBtnTextClose: '关闭',

	udDNDTextDropFiles: '拖拽文档到这里',
	udDNDTextClickHere: '或者点击这里去选择文档',

	// Upload File Item
	ufiTextUploading: '正在上传...',
	ufiBtnTitleKeepBoth: '作为新文档上传',
	ufiBtnTitleOverwrite: '覆盖现有同名的文档',

	// Upload Saga
	usErrorTextSessionError: '上传会话错误',
	usErrorTextValidationError: '验证',
	usErrorTextValidationErrorDetails: '抱歉，获取验证结果有效状态失败。',
	usErrorTextUploadCommitError: '上传错误',
	usErrorTextUploadCommitErrorDetails: '抱歉，上传文档失败。',
	usErrorTextCancellationError: '抱歉，无法取消正在上传的文档。',

	// Information panel
	infoPanelProperties: '文档属性',
	infoPanelUpdated: '更新时间',
	infoPanelUpdatedBy: '更新者',
	infoPanelCreated: '创建时间',
	infoPanelCreatedBy: '创建者',
	infoPanelPermissions: '访问权限',
	infoPanelCategories: '文档分类',
	infoPanelDescription: '文档描述',
	infoPanelDescriptionPlaceholder: '请输入文档描述',
	infoPanelMobileVisible: '移动端显示',
	infoPanelMobileVisibleShow: '显示',
	infoPanelMobileVisibleHide: '隐藏',
	infoPanelHideInDocumentPortal: '在文档门户中隐藏',
	infoPanelHideInDocumentPortalShowStateLabel: '否',
	infoPanelHideInDocumentPortalHideStateLabel: '是',

	// Document info
	docInfoRevisions: '修订历史',
	docInfoInfo: '基本信息',
	docInfoSelectDocumentText: '选择一个文档查看详细信息',
	docInfoNoComment: '没有描述',
	commentWithVersion: '版本 {{no}}: {{comment}}',

	// Search drawer
	searchDrawerSearch: '搜索',
	searchDrawerNoResult: '没有查到任何结果',
	searchDrawerTip: '请输入文档名称',
	searchDrawerResult: '搜索结果',

	// Document  list
	docListNoDocuments: '该分类中没有文档',
	docListSortName: '名称',
	docListSortType: '类型',
	docListSortModified: '修改时间',
	docListSortCreated: '创建时间',

	// Document item
	docItemSetAsHome: '设为主页',
	docItemSetAsHomeDescription: '这个文档将默认被打开',
	docItemRename: '重命名',
	docItemRenameDescription: '重命名文档',
	docItemSetCategory: '管理分类',
	docItemSetCategoryDescription: '编辑文档的分类',
	docItemSetDelete: '删除文档',
	docItemSetDeleteDescription: '删除这个文档',
	docItemEdit: '编辑文档',
	docItemEditTitle: '编辑这个文档',
	docItemAddToFavorites: '收藏',
	docItemRemoveFromFavorites: '取消收藏',
	docItemDownload: '下载',
	docItemDownloadDescription: '下载该文档',

	// Tag editor
	tagsEditorCategories: '管理分类',
	tagsEditorCurrent: '已选分类',
	tagsEditorNoCategoriesText: '未设置任何分类',
	tagsEditorAvailableCategories: '可选分类',
	tagsEditorNoAvailableCategories: '没有可选的分类',

	// Document delete dialog
	deleteDocumentDialogTitle: '删除文档',
	deleteDocumentConfirmMsg: '永久删除文档“{{name}}”？',
	ok: '确定',
	cancel: '取消',
	close: '关闭',
	back: '返回',

	// Workspace
	workspaceInfo: '详情',
	workspaceRefresh: '刷新',
	workspaceFullscreen: '全屏',
	workspaceNewWindow: '在新窗口中浏览{{type}}',
	workspaceNoDocumentTip: '欢迎您使用本产品，请进行以下操作',
	workspaceNoHomeTip: '您还未设置个人主页，请从左侧菜单开始使用文档',
	workspaceOpenSomeDocuments: '查看文档',
	workspacePickDocumentToOpen: '从左边列表中选择文档进行查看',
	workspaceSetUpHome: '设置主页',
	workspaceChooseFromMenu: '从左边列表中选择文档，点击',
	workspaceSetAsHome: '',
	workspaceCloseAll: '关闭全部标签页',
	workspaceCloseAllButActive: '关闭其他标签页',
	workspaceCloseActive: '关闭当前标签页',
	workspacePreviewIsUnavailable: '此文档类型不支持预览 :(',

	// Document Types
	'rdl!name': '报表',
	'rdl!description': '报表',
	'rdlx-template!name': '报表模板',
	'rdlx-template!description': '报表模板',
	'rdlx-master!name': '母版报表',
	'rdlx-master!description': '母版报表',
	'theme!name': '主题',
	'theme!description': '主题',
	'dbd!name': '仪表板',
	'dbd!description': '仪表板',
	'dsc!name': '数据源',
	'dsc!description': '数据源',
	'dataset!name': '数据集',
	'dataset!description': '数据集',

	'image/bmp!name': 'BMP 图片',
	'image/bmp!description': '位图图片',
	'image/jpeg!name': 'JPEG 图片',
	'image/jpeg!description': 'JPEG 图片',
	'image/gif!name': 'GIF 图片',
	'image/gif!description': 'GIF 图片',
	'image/png!name': 'PNG 图片',
	'image/png!description': 'PNG 图片',

	// Verbs
	'imagePreview!name': '图片预览',
	'imagePreview!description': '图片预览',

	// Document Verbs
	'imagePreviewRevision!name': '图片预览',
	'imagePreviewRevision!description': '图片预览',
	'copyReport!name': '复制',
	'copyReport!description': '复制这个文档',
	'copyDashboard!name': '复制',
	'copyDashboard!description': '复制这个文档',
	'copySemanticModel!name': '复制',
	'copySemanticModel!description': '复制这个文档',

	// Document Info
	'schedule_tasks!name': '运行计划',
	'schedule_tasks!description': '文档的运行计划管理',
	'schedule_history!name': '运行历史',
	'schedule_history!description': '文档运行的历史记录',

	// Portal sagas
	connectionError: '连接错误',
	initializeError: '初始化错误',
	noPluginsFound: '未发现任何插件',
	incorrectCategories: '错误的标签',
	getHomeDocumentError: '获取主文档失败',
	updateDocListError: '更新文档列表失败',
	somethingWentWrong: '发生了未知错误',
	categoryCannotAvailable: '文档分类"{{name}}"已经不存在了。它也许被移动，重命名或者删除了。',
	documentNotDeleted: '文档删除失败',
	documentUsedByAnother: '文档\"{{docName}}\"不能被删除，该文档被下列文档引用：\n{{refDocNames}}',
	changePermissionError: '更新文档权限失败',
	assignCategoryError: '指定文档分类失败',
	createCategoryError: '创建文档分类失败',
	updateCategoryError: '更新文档分类失败',
	wrongDataFormat: '错误的数据格式',
	renameDocumentError: '重命名文档失败',
	duplicateDocumentError: '复制文档失败',
	duplicateDocumentSuccess: '复制文档成功',
	copyDocumentSuffix: '-副本',

};
