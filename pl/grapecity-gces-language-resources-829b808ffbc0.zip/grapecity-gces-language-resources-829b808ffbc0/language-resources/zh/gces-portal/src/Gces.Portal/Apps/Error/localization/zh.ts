export const errorZH: LanguageKeyValueMap = {
	err_default: '出现了一个错误，抱歉！',
	err_invalid_license: '无效的产品授权',
	err_invalid_license_desc: '产品授权已经过期. 请联系你的管理员。',
	err_invalid_license_verion_not_match_desc: '授权和产品版本不匹配，请尝试刷新授权。',
	adminPortal: '系统管理',

	// Reports
	err_reports_10001: '报表文档数量已经达到限制，无法创建新报表。',

	// Dashboards
	err_dashboards_10001: '仪表板文档数量已经达到限制，无法创建新仪表板。',

	// common
	err_common_10001: '此文档已经被删除，请刷新文档列表。',
	err_common_10002: '您没有这个文档的访问权限，请刷新文档列表。',
	err_common_10003: '您没有权限访问此页面，或者您在访问一个无效链接。',
};