﻿export const reportingZH: LanguageKeyValueMap = {

	// Tile
	tTextNoWorkers: '无可用的工作线程',
	tStatusIdle: '空闲',

	tBtnTitleEnable: '启用磁贴更新',
	tBtnTitleDisable: '禁用磁贴更新',

	// Tasks Tile
	ttStatusTextInProgress: '处理中',
	ttStatusTextComplete: '完成',
	ttStatusTextInCancelled: '取消',
	ttStatusTextInFailed: '失败',
	ttStatusTextInQueued: '排队中',

	ttTextNoDataAvailable: '没有可用的数据',

	// Saga
	sagaErrorConnection: '连接错误',
	sagaErrorConnectionDetails: '无法加载必须的数据',

}
