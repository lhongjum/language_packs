export const reportingZH: LanguageKeyValueMap = {

	// Designer
	drApplicationTitle: '报表',
	drYes: '确定',
	drNo: '取消',
	drUnsavedChangesTitle: '发现未保存的修改',
	drUnsavedChangesText: '当前文档有未保存的修改，确认离开？',

	// Export Dialog
	edTextFormat: '导出格式',
	edTextParams: '报表参数',
	edTextExportParams: '导出参数',
	edTextReadyToExport: '可进行导出操作',
	edTextExport: '导出',
	edTextExportError: '导出错误',
	edTextExportTo: '导出为 {{type}}',
	edTextChooseExportFormat: '请选择导出格式',
	edTextAdvancedSettings: '高级设置',

	edStatusTextGettingInfo: '加载报表信息...',
	edStatusTextInfoUnavailable: '没有可用的报表信息',

	edHeaderParameters: '设置报表参数',
	edHeaderSettings: '导出设置',
	edExportBtnText: '导出',
	edNextBtnText: '下一步',
	edCancelBtnText: '取消',
	edCancelBtnTitle: '取消导出',

	// Template Wizard
	tpTagName: '报表模板',
	tpWizardTitle: '请选择模板',
	tpWizardHeaderCategories: '文档分类',
	tpWizardHeaderTemplates: '报表模板',
	tpWizardHeaderDetails: '详细信息',
	tpWizardSearchPlaceholder: '请输入模板名称',
	tpWizardViewModeGallery: '磁贴视图',
	tpWizardViewModeList: '列表视图',
	tpCreateReport: '创建报表',
	tpCancel: '取消',
	tpSelectTemplateText: '请选中一个报表模板，以查看详细说明',
	tpSelectCategoryText: '请选择一个分类，以查看可用的报表模板',

	tpDetailsName: '报表模板名称',
	tpDetailsDescription: '使用描述',
	tpDetailsCreated: '创建时间',
	tpDetailsCreatedBy: '创建者',
	tpDetailsModified: '更新时间',
	tpDetailsModifiedBy: '修改者',

	tpWizardBlankPage: '空白页面报表',
	tpWizardBlankRDL: '空白RDL报表',

	sysTagNoCategory: '未分类',
	sysTagResources: '资源库',
	sysTagFavorites: '收藏夹',
	sysTagImages: '图片',
	sysTagThemes: '主题',
	pluginTemplates: '报表模板',

	// Saga
	sagaQueueErrorTaskFailed: '任务失败',
	sagaQueueErrorExecFailed: '不能执行该任务',
	sagaQueueErrorNoWorkers: '没有可用的任务执行者',
	sagaQueueErrorUnknown: '未知错误',

	sagaTaskStatusExporting: '正在将 {{doc}} 导出为 {{type}}',
	sagaTaskStarting: '启动中...',

	sagaErrorExportFailed: '导出失败',
	sagaErrorExportFailedDetails: '不能执行导出操作',
	sagaErrorExportFailedParams: '不能加载报表参数',
	sagaErrorExportFailedParamValues: '不能获得参数值',

	sagaFail: '报表: 未知错误',

	sagaQueueErrorCaption: '执行队列错误',
	sagaQueueError1Content: '任务被取消',
	sagaQueueError2Content: '任务处理失败',
	sagaQueueError3Content: '未知的内部错误',
	sagaQueueError4Content: '没有可用的工作线程',
	sagaQueueError5Content: '需要配置任务对应的访问URL',

	updateTemplateListError: '更新报表模板列表失败',

	// Document Types
	'report!name': '报表',
	'report!description': '报表',
	'template!name': '报表模板',
	'template!description': '报表模板',
	'masterReport!name': 'Master Report',
	'masterReport!description': 'Master Report',

	// Verbs
	'createReport!name': '创建报表',
	'createReport!description': '创建报表',

	'editReport!name': '编辑',
	'editReport!description': '编辑报表',

	'exportReport!name': '导出',
	'exportReport!description': '导出报表',

	'reportPreview!name': '预览报表',
	'reportPreview!description': '预览报表',

	'templatePreview!name': '预览Html效果',
	'templatePreview!description': '将报表模板显示为 Html 页面，以便于预览模板效果',

	'createReportWithTemplate!name': '创建报表',
	'createReportWithTemplate!description': '用当前模版创建报表',

	'copyAsTemplate!name': '复制为报表模板',
	'copyAsTemplate!description': '复制为报表模板文件',
	copyDocumentSuffix: '-模板',

	'editTemplate!name': '编辑',
	'editTemplate!description': '编辑报表',

	// Revision Verbs
	'previewRevision!name': '预览',
	'previewRevision!description': '预览报表的该版本',

	'editRevision!name': '编辑',
	'editRevision!description': '编辑报表的该版本',

	// Commands Dialog
	'commands!name': '工具栏选项/按钮',
	'commands!description': '设置用户可见的工具栏选项/按钮',
	'commands!btnText': '编辑',
	'commandsEditor': '工具栏选项',
	'commandsEditorCurrent': '已选择工具栏选项/按钮',
	'commandsEditorNoCategoriesText': '还未选择任何工具栏选项',
	'commandsEditorAvailableCategories': '可用选项',
	'commandsEditorNoAvailableCategories': '没有可用的工具栏选项',
	'commands$navigation': '翻页',
	'commands$refresh': '刷新',
	'commands$history': '前进后退',
	'commands$mousemode': '平移',
	'commands$zoom': '缩放',
	'commands$fullscreen': '全屏',
	'commands$print': '打印',
	'commands$singlepagemode': '单页视图',
	'commands$continuousmode': '多页视图',
	'commands$galleymode': '不分页',
	'commands$pdf': 'PDF',
	'commands$excel': 'Excel',
	'commands$docx': 'Word',
	'commands$image': 'Image',
	'commands$html': 'HTML',
	'commands$csv': 'CSV',
	'commands$json': 'JSON',
	'commands$txt': 'TXT',
	'commands$xml': 'XML',

	saveCommandsError: '保存工具栏选项时出现错误',
	getCommandsError: '加载工具栏选项时出现错误',

	// Document Error Message
	documentNotDeleted: '无法删除该文档',
	documentUsedByAnother: '文档\"{{docName}}\"被以下文档所引用，无法直接删除。\n{{refDocNames}}',
	renameDocumentError: '重命名失败',
	duplicateDocumentError: '复制文档失败',
	err_AccessDenied: '无法复制该文档，因为你没有编辑该文档所引用资源的权限。',
	previewDocumentError: '预览失败',
	errorAccessDenied: '你没有该文档所引用资源的使用权限',

	// Reporting Plugin Exceptions
	reportingPluginUnknown: '报表任务执行过程中，发生了未知错误',
	reportingPluginLrt: '报表的长任务运行发生异常',
	reportingPluginBadResponse: '报表工作线程失去响应',
	reportingPluginStreaming: '报表工作线程进行流式传输过程中发生一个错误',
	reportingPluginResponseVerification: '报表工作线程在流式传输之后发生一个错误',

	// Worker Exceptions
	reportingWorkerExportInvalidParameters: '无效的报表参数',
	reportingWorkerExportUnknownRenderingExt: '不支持将报表导出为 {0} 格式',

	reportingWorkerTaskInitUnknown: '报表工作线程在执行以下任务时发生了未知错误: {0}',
	reportingWorkerTaskInitFileNotFound: '未找到文件 {0} ',
	reportingWorkerTaskInitUnableToLoadFile: '无法加载文件 {0}',

	reportingWorkerFailCheckInvalidParameters: '无效的报表参数',
	reportingWorkerFailCheckUnknown: '报表工作线程在执行以下任务时发生了未知错误: {0}',
	reportingWorkerFailCheckNoDataset: '未指定数据集',

	reportingWorkerRenderingDatasetNotFound: '无法加载指定的数据集，可能是因为访问权限不足、或者文件不存在',
	reportingWorkerRenderingDatasourceNotFound: '无法加载指定的数据源，可能是因为访问权限不足、或者文件不存在',
	reportingWorkerRenderingUnknown: '报表工作线程在执行以下任务时发生了未知错误: {0}',

	reportingWorkerReportUnknown: '在获取以下报表基本信息时发生未知错误: {0}',
	reportingWorkerReportCyclicParameterReferences: '报表的参数之间存在循环引用，请检查',

	// Document Section
	referencedDataDocuments: '引用的数据文档',
}
