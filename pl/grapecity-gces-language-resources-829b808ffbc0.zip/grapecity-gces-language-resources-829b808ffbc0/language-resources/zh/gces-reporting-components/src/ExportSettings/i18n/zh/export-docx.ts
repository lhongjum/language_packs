import { PaperSize } from './common/PaperSize';

export default {
  "friendlyName": "Word",
  "tooltipName": "Word Document(.docx)",
  "settings": {
    "Title": {
      "label": "标题",
      "category": "信息"
    },
    "Author": {
      "label": "作者",
      "category": "信息"
    },
    "DpiX": {
      "label": "横向分辨率",
      "category": "信息"
    },
    "DpiY": {
      "label": "纵向分辨率",
      "category": "信息"
    },
    "DocumentCompatibilityVersion": {
      "label": "文档兼容性版本",
      "category": "信息",
      "enum": {
        "Word2007": "Word2007",
        "Word2010": "Word2010",
        "Word2013": "Word2013"
      }
    },
    "TOCAutoUpdate": {
      "label": "自动更新目录",
      "category": "信息"
    },
    "CompanyName": {
      "label": "公司名称",
      "category": "信息"
    },
    "WritePassword": {
      "label": "编辑密码",
      "category": "安全设置"
    },
    "Password": {
      "label": "密码",
      "category": "安全设置"
    },
    "ReadOnlyRecommended": {
      "label": "只读",
      "category": "安全设置"
    },
    "Orientation": {
      "label": "纸张方向",
      "category": "页面设置",
      "enum": {
        "Default": "默认",
        "Portrait": "纵向",
        "Landscape": "横向"
      }
    },
    "PaperSize": {
      "label": "纸张大小",
      "category": "页面设置",
      "enum": PaperSize
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
