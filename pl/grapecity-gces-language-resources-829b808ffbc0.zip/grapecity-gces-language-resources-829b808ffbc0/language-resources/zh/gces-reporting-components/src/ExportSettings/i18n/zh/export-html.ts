export default {
  "friendlyName": "HTML",
  "tooltipName": "HTML Document",
  "settings": {
    "EmbedImages": {
      "label": "嵌入图片",
      "category": "输出选项"
    },
    "Fragment": {
      "label": "分段",
      "category": "输出选项"
    },
    "StyleStream": {
      "label": "样式表",
      "category": "输出选项"
    },
    "OutputTOC": {
      "label": "输出目录",
      "category": "输出选项"
    },
    "RenderMode": {
      "label": "模式",
      "category": "渲染选项",
      "enum": {
        "Galley": "不分页",
        "Paginated": "分页选项"
      }
    },
    "RenderingEngine": {
      "label": "渲染方式",
      "category": "渲染选项",
      "enum": {
        "Html": "Html",
        "Mixed": "混合模式"
      }
    },
    "LinkTarget": {
      "label": "超链接目标",
      "category": "渲染选项"
    },
    "EndPage": {
      "label": "最后一页",
      "category": "信息"
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
