export default {
  "friendlyName": "纯文本",
  "tooltipName": "TXT Document",
  "settings": {
    "FontWeight": {
      "label": "字重",
      "category": "信息"
    },
    "FontHeight": {
      "label": "字高",
      "category": "信息"
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
