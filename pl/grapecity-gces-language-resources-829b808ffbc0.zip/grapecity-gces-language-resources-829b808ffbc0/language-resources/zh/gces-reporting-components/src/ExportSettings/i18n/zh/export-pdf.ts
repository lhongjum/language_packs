import { WatermarkColor } from "./common/WatermarkColor";
import { WatermarkFontFamily } from "./common/WatermarkFontFamily";

export default {
  "friendlyName": "文件",
  "tooltipName": "PDF Document",
  "settings": {
    "Version": {
      "label": "版本",
      "category": "信息",
      "enum": {
        "Pdf12": "PDF-1.2",
        "Pdf13": "PDF-1.3",
        "Pdf14": "PDF-1.4",
        "Pdf15": "PDF-1.5",
        "Pdf16": "PDF-1.6",
        "Pdf17": "PDF-1.7",
        "PdfA1a": "PDF/A-1a",
        "PdfA1b": "PDF/A-1b",
        "PdfA2a": "PDF/A-2a",
        "PdfA2b": "PDF/A-2b",
        "PdfA2u": "PDF/A-2u",
        "PdfA3a": "PDF/A-3a",
        "PdfA3b": "PDF/A-3b",
        "PdfA3u": "PDF/A-3u",
        "PdfUA1": "PDF/UA-1"
      }
    },
    "EmbedFonts": {
      "label": "嵌入字体",
      "category": "信息",
      "enum": {
        "Partial": "部分嵌入",
        "All": "全部嵌入",
        "None": "不嵌入"
      }
    },
    "NeverEmbedFonts": {
      "label": "不嵌入字体",
      "category": "信息"
    },
    "PrintOnOpen": {
      "label": "打开时打印",
      "category": "信息"
    },
    "Title": {
      "label": "标题",
      "category": "信息"
    },
    "Author": {
      "label": "作者",
      "category": "信息"
    },
    "Subject": {
      "label": "主题",
      "category": "信息"
    },
    "Keywords": {
      "label": "关键字",
      "category": "信息"
    },
    "Application": {
      "label": "应用程序",
      "category": "信息"
    },
    "Permissions": {
      "label": "权限",
      "category": "信息",
      "enum": {
        "None": "无",
        "AllowPrint": "允许打印",
        "AllowModifyContents": "允许编辑内容",
        "AllowCopy": "允许复制",
        "AllowModifyAnnotations": "允许编辑批注",
        "AllowFillIn": "允许填入数据",
        "AllowAccessibleReaders": "允许访问的读者",
        "AllowAssembly": "允许组合",
        "Default": "默认"
      }
    },
    "Use128Bit": {
      "label": "使用128Bit",
      "category": "信息"
    },
    "HideToolbar": {
      "label": "隐藏工具栏",
      "category": "信息"
    },
    "HideMenubar": {
      "label": "隐藏菜单栏",
      "category": "信息"
    },
    "HideWindowUI": {
      "label": "隐藏窗口界面",
      "category": "信息"
    },
    "FitWindow": {
      "label": "适应窗口",
      "category": "信息"
    },
    "CenterWindow": {
      "label": "窗口居中",
      "category": "信息"
    },
    "DisplayTitle": {
      "label": "显示标题",
      "category": "信息"
    },
    "DisplayMode": {
      "label": "显示模式",
      "category": "信息",
      "enum": {
        "None": "无",
        "Outlines": "大纲",
        "Thumbs": "缩略图",
        "FullScreen": "全屏"
      }
    },
    "DuplexMode": {
      "label": "双工模式",
      "category": "信息",
      "enum": {
        "Simplex": "单面",
        "DuplexFlipLongEdge": "双面翻转长边",
        "DuplexFlipShortEdge": "双面翻转短边"
      }
    },
    "NumberOfCopies": {
      "label": "打印份数",
      "category": "信息"
    },
    "ImageInterpolation": {
      "label": "图片插值",
      "category": "信息",
      "enum": {
        "Default": "默认",
        "None": "无"
      }
    },
    "PaperSourceByPageSize": {
      "label": "纸张来源（按页面大小）",
      "category": "信息"
    },
    "PrintPageRange": {
      "label": "打印页面范围",
      "category": "信息"
    },
    "IsPaginated": {
      "label": "分页",
      "category": "信息"
    },
    "PrintLayoutMode": {
      "label": "打印版面模式",
      "category": "信息",
      "enum": {
        "OneLogicalPageOnSinglePhysicalPage": "每版打印 1 页",
        "TwoLogicalPagesOnSinglePhysicalPage": "每版打印 2 页",
        "FourLogicalPagesOnSinglePhysicalPage": "每版打印 4 页",
        "EightLogicalPagesOnSinglePhysicalPage": "每版打印 8 页",
        "BookletMode": "小册子模式"
      }
    },
    "SizeToFit": {
      "label": "大小自适合",
      "category": "信息"
    },
    "StartPage": {
      "label": "起始页码",
      "category": "信息"
    },
    "EndPage": {
      "label": "结束页码",
      "category": "信息"
    },
    "WatermarkAngle": {
      "label": "水印角度",
      "category": "信息"
    },
    "WatermarkColor": {
      "label": "水印颜色",
      "category": "信息",
      "enum": WatermarkColor
    },
    "WatermarkTitle": {
      "label": "水印标题",
      "category": "信息"
    },
    "WatermarkFontFamily": {
      "label": "水印字体",
      "category": "信息",
      "enum": WatermarkFontFamily
    },
    "WatermarkFontSize": {
      "label": "水印字体大小",
      "category": "信息"
    },
    "WatermarkFontBold": {
      "label": "水印字体加粗",
      "category": "信息"
    },
    "WatermarkFontItalic": {
      "label": "水印字体斜体",
      "category": "信息"
    },
    "WatermarkFontStrikeout": {
      "label": "水印字体删除线",
      "category": "信息"
    },
    "WatermarkFontUnderline": {
      "label": "水印字体下滑线",
      "category": "信息"
    },
    "Encrypt": {
      "label": "加密",
      "category": "安全设置"
    },
    "OwnerPassword": {
      "label": "作者密码",
      "category": "安全设置"
    },
    "UserPassword": {
      "label": "用户密码",
      "category": "安全设置"
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
