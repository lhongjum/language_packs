import { PaperSize } from './common/PaperSize';

export default {
  "friendlyName": "Excel",
  "tooltipName": "Excel Book",
  "settings": {
    "UseCompression": {
      "label": "启用压缩",
      "category": "信息"
    },
    "OutputFormat": {
      "label": "输出格式",
      "category": "信息",
      "enum": {
        "OpenXmlTransitional": "Transitional",
        "OpenXmlStrict": "Strict"
      }
    },
    "EnableToggles": {
      "label": "启用切换",
      "category": "信息"
    },
    "Pagination": {
      "label": "分页显示",
      "category": "信息"
    },
    "UseDefaultPalette": {
      "label": "使用默认调色板",
      "category": "信息"
    },
    "MultiSheet": {
      "label": "多页",
      "category": "信息"
    },
    "SheetName": {
      "label": "工作表名字",
      "category": "信息"
    },
    "ProtectedBy": {
      "label": "受保护",
      "category": "安全"
    },
    "WritePassword": {
      "label": "编辑密码",
      "category": "安全"
    },
    "ReadOnlyRecommended": {
      "label": "只读模式打开",
      "category": "安全"
    },
    "Orientation": {
      "label": "纸张方向",
      "category": "纸张设置",
      "enum": {
        "Default": "默认",
        "Portrait": "纵向",
        "Landscape": "横向"
      }
    },
    "PaperSize": {
      "label": "纸张大小",
      "category": "纸张设置",
      "enum": PaperSize
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
