import { WatermarkColor } from "./common/WatermarkColor";
import { WatermarkFontFamily } from "./common/WatermarkFontFamily";

export default {
  "friendlyName": "图片",
  "tooltipName": "PNG Image",
  "settings": {
    "ImageType": {
      "label": "图片类型",
      "category": "信息",
      "enum": {
        "Png": "PNG",
        "Jpeg": "JPEG",
        "Gif": "GIF",
        "Bmp": "BMP",
        "Tiff": "TIFF"
      }
    },
    "Pagination": {
      "label": "分页",
      "category": "信息"
    },
    "DpiX": {
      "label": "横向分辨率",
      "category": "信息"
    },
    "DpiY": {
      "label": "纵向分辨率",
      "category": "信息"
    },
    "Quality": {
      "label": "质量",
      "category": "信息"
    },
    "Dither": {
      "label": "抖动",
      "category": "信息"
    },
    "PrintLayoutMode": {
      "label": "打印版面模式",
      "category": "信息",
      "enum": {
        "OneLogicalPageOnSinglePhysicalPage": "每版打印 1 页",
        "TwoLogicalPagesOnSinglePhysicalPage": "每版打印 2 页",
        "FourLogicalPagesOnSinglePhysicalPage": "每版打印 4 页",
        "EightLogicalPagesOnSinglePhysicalPage": "每版打印 8 页",
        "BookletMode": "小册子模式"
      }
    },
    "SizeToFit": {
      "label": "大小自适合",
      "category": "信息"
    },
    "StartPage": {
      "label": "起始页码",
      "category": "信息"
    },
    "EndPage": {
      "label": "结束页码",
      "category": "信息"
    },
    "WatermarkAngle": {
      "label": "水印角度",
      "category": "信息"
    },
    "WatermarkColor": {
      "label": "水印颜色",
      "category": "信息",
      "enum": WatermarkColor
    },
    "WatermarkTitle": {
      "label": "水印标题",
      "category": "信息"
    },
    "WatermarkFontFamily": {
      "label": "水印字体",
      "category": "信息",
      "enum": WatermarkFontFamily
    },
    "WatermarkFontSize": {
      "label": "水印字体大小",
      "category": "信息"
    },
    "WatermarkFontBold": {
      "label": "水印字体加粗",
      "category": "信息"
    },
    "WatermarkFontItalic": {
      "label": "水印字体斜体",
      "category": "信息"
    },
    "WatermarkFontStrikeout": {
      "label": "水印字体删除线",
      "category": "信息"
    },
    "WatermarkFontUnderline": {
      "label": "水印字体下滑线",
      "category": "信息"
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
