export default {
  "friendlyName": "JSON",
  "tooltipName": "JSON",
  "settings": {
    "Formatted": {
      "label": "格式化",
      "category": "信息"
    },
    "QuotePropertyNames": {
      "label": "引用属性名称",
      "category": "信息"
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
