import { Encoding } from "./common/Encoding";

export default {
  "friendlyName": "CSV",
  "tooltipName": "CSV Document",
  "settings": {
    "Encoding": {
      "label": "编码格式",
      "category": "信息",
      "enum": Encoding
    },
    "NoHeader": {
      "label": "无标题",
      "category": "信息"
    },
    "ColumnsDelimiter": {
      "label": "列分隔符",
      "category": "信息"
    },
    "RowsDelimiter": {
      "label": "行分隔符",
      "category": "信息"
    },
    "QuotationSymbol": {
      "label": "引用符号",
      "category": "信息"
    },
    "Extension": {
      "label": "扩展设置",
      "category": "信息",
      "enum": {
        "csv": ".csv",
        "txt": ".txt"
      }
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
