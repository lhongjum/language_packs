export default {
  "friendlyName": "XML",
  "tooltipName": "XML 文件",
  "settings": {
    "Formatted": {
      "label": "格式",
      "category": "其他"
    },
    "WriteEmptyAttributes": {
      "label": "输出空属性",
      "category": "其他"
    },
    "OutputHiddenMatrixMembers": {
      "label": "输出隐藏成员",
      "category": "其他"
    },
    "OutputTextboxConstantValues": {
      "label": "输出文本框常量值",
      "category": "其他"
    },
    "DefaultDateFormat": {
      "label": "默认日期格式",
      "category": "其他"
    },
    "AddTimestamp": {
      "label": "文件名称追加时间戳",
      "category": "文件名称"
    }
  }
}
