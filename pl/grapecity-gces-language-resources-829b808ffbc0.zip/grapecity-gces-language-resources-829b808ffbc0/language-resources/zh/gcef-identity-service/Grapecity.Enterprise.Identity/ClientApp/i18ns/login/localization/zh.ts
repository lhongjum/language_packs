export const zh: LanguageKeyValueMap = {
	ExternalAuthenticationError: '外部认证失败。',
	InvalidUsernameOrPassword: '无效的用户名或者密码。',
	Login: '登录',
	NoBindingInfoForUser: "不存在用户'{{userName}}'的绑定信息。",
	PasswordCountLimit: '你已经连续输入密码错误{{times}}次， 请在{{minutes}}分钟后重试。',
	PasswordRequired: '密码不能为空。',
	ProviderNotExist: "外部用户提供者'{{providerName}}'不存在。",
	UnknownUserId: '未知的用户ID',
	UsernameRequired: '用户名不能为空。',
	LOGO: '商标',
	Password: '密码',
	RememberMe: '记住登录信息	',
	SignIn: '登录',
	SignInToYourAccount: '登录到您的帐户',
	Username: '用户名',
	ForgotPassword: '忘记密码？',

	// forgot password
	Save: '保存',
	ResetPassword: '重置密码',
	ResetPasswordTip: '请输入与您账号关联的电子邮箱地址。',
	EnterEmailAddress: '请输入您的邮箱地址',
	SendResetPasswordEmail: '发送重置密码邮件',
	InvalidEmailError: '错误的邮箱地址格式。',
	UserWithEmailNotFoundError: '与该邮箱地址关联的账号不存在。',
	ResetPasswordRequestTooFrequentlyError: '对不起，您重置密码的的请求过于频繁，请稍候再试。',
	SendResetPasswordRequestFailedError: '对不起，重置密码的请求失败，请重新尝试。',

	// forgot password confirm
	ForgotPasswordConfirmMessage: '我们已经发送了一封电子邮件到您的邮箱“{{ email }}”，请按照邮件说明来重置您的密码。',
	GoToLoginPage: '返回登录页面',

	// reset password
	SetNewPassword: '设置新密码',
	EnterNewPassword: '输入新密码',
	ConfirmNewPassword: '确认新密码',
	InvalidResetPasswordRequestError: '非法的重置密码请求。',
	PasswordEmptyError: '密码不能为空。',
	InvalidPasswordFormatError: '密码长度应该在8-32位，且必须包含一个大写字母，一个小写字母和一个数字。',
	ConfirmPasswordNotMatchError: '确认密码和密码不匹配。',
	InvalidResetPasswordCodeError: '非法的重置密码密钥。',
	PasswordAlreadyResetError: '密码已经被重置过。',
	ExpiredResetPasswordRequestError: '重置密码的请求已过期。',
	UserNotFoundError: '没有找到与该重置密码请求相关联的用户。',
	InvalidEmailSettingsError: '非法的邮箱配置，请联系管理员配置可正常使用的邮箱账户。',
	ExpiredResetPasswordLinkError: '对不起，该重置密码的链接已经失效。',
	EmptyIdentityUri: '邮件发送失败，请在配置文件中设置正确的“Identity Server URL”。',
	EmptyPortalUri: '邮件发送失败，请在“系统外观”页面中设置正确的“门户网站地址”。',

	// reset password confirm
	ResetPasswordConfirmMessage: '您已经成功设置了新的密码，请使用新的密码登录。',

	// login to tenant
	Ok: '确定',
	SelectOrganization:'请选择需要登录的组织',
}