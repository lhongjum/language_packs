export const zh: LanguageKeyValueMap = {
	Ok: '确定',
	SelectOrganization:'请选择需要登录的组织',
}