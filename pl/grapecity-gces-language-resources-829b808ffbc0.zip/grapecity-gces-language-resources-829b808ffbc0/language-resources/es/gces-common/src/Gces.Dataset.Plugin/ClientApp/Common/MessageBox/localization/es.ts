export const mbLocaleES = {
    OK: 'OK',
    MessageBox: 'Message',
};
