export const es: LanguageKeyValueMap = {
	Ok: 'OK',
	SelectOrganization: 'Please select organization',
}